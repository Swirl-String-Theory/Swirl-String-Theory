import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  scrolled = false;
  menuOpen = false;

  papers = [
    { title: "A Unified Electron Scale Relation from Classical Radius, Compton Frequency, and Hydrogen Energy", color: "text-physics-purple" },
    { title: "Rotational Kinetic Energy Density and an Effective Mass Relation in Incompressible Fluids", color: "text-physics-cyan" },
    { title: "Circulation, Rigid Rotation, and Proper Time Dilation: A Fluid Representation", color: "text-physics-gold" },
    { title: "Energy, Impulse, and Stability of Thin Vortex Loops in Incompressible Fluids", color: "text-physics-cyan" },
    { title: "Swirl Pressure and Effective Gravitational Acceleration in Rotating Flows", color: "text-physics-gold" },
    { title: "Impulsive Axisymmetric Forcing in a Rotating Cylinder and Skyrmionic Photon Fields", color: "text-physics-purple" }
  ];

  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.scrolled = window.scrollY > 50;
  }

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  scrollToSection(id: string) {
    this.menuOpen = false;
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  }
}