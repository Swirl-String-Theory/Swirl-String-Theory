import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AppComponent } from './app.component';
import { HeroSceneComponent } from './components/hero-scene.component';
import { FluidSceneComponent } from './components/fluid-scene.component';
import { ElectronScaleComponent } from './components/electron-scale.component';
import { VortexCalcComponent } from './components/vortex-calc.component';
import { EnergyChartComponent } from './components/energy-chart.component';
import { SstExplorerComponent } from './components/sst-explorer.component';

@NgModule({
  declarations: [
    AppComponent,
    HeroSceneComponent,
    FluidSceneComponent,
    ElectronScaleComponent,
    VortexCalcComponent,
    EnergyChartComponent,
    SstExplorerComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }