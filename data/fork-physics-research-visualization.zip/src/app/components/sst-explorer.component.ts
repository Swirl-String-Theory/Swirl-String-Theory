import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener } from '@angular/core';

@Component({
  selector: 'app-sst-explorer',
  template: `
    <div class="sst-wrapper font-sans text-slate-300 w-full bg-[#0b0d12] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      <header class="flex justify-between items-center p-4 bg-[#151922] border-b border-slate-800">
          <div>
              <h1 class="m-0 text-lg uppercase tracking-wider bg-gradient-to-r from-physics-cyan to-[#ff2a6d] bg-clip-text text-transparent font-bold">
                  SST: Swirl-String Theory
              </h1>
              <div class="text-xs opacity-70">Interference, Knot Collapse & Duality</div>
          </div>
          <div class="text-xs text-slate-500 font-mono">Canon v0.3.1</div>
      </header>

      <main class="flex flex-col lg:flex-row h-[600px] relative">
          <!-- Canvas Container -->
          <div class="flex-1 relative bg-[radial-gradient(circle_at_center,#1a1e29_0%,#000000_100%)] overflow-hidden" #canvasContainer>
              <canvas #simCanvas class="block w-full h-full"></canvas>
              
              <!-- Readout Overlay -->
              <div class="absolute top-5 left-5 bg-[#151922]/80 backdrop-blur-sm p-4 rounded-lg border border-white/10 max-w-[280px] pointer-events-none select-none z-10">
                  <h2 class="m-0 mb-2 text-sm text-white font-bold border-b border-white/10 pb-1">Current State</h2>
                  <p class="m-0 text-xs leading-relaxed" [innerHTML]="stateDesc" [style.border-left-color]="stateBorderColor" style="border-left-width: 3px; padding-left: 8px;"></p>
              </div>
          </div>

          <!-- Controls Aside -->
          <aside class="w-full lg:w-[320px] bg-[#151922] border-l border-slate-800 p-5 flex flex-col gap-5 overflow-y-auto custom-scrollbar shadow-xl z-20">
              
              <!-- Phase Viz -->
              <div class="bg-black/20 p-4 rounded-lg border border-slate-800">
                  <h3 class="mt-0 text-sm text-white border-b border-slate-700 pb-2 mb-4 font-semibold">Phase Visualization</h3>
                  <div class="flex justify-center gap-6 mb-4 items-center h-12">
                      <div class="w-8 h-8 border-[3px] border-physics-cyan rounded-full animate-spin-slow shadow-[0_0_10px_rgba(34,211,238,0.3)]" title="Phase R"></div>
                      <div class="self-center text-slate-500 text-lg">⇄</div>
                      <div class="w-8 h-8 relative shape-knot" title="Phase T"></div>
                  </div>
                  <div class="space-y-2">
                    <div class="flex items-center gap-2 text-xs text-slate-400">
                        <span class="w-2 h-2 rounded-full bg-physics-cyan shadow-[0_0_5px_#22d3ee]"></span> Phase R (Wave/Ring)
                    </div>
                    <div class="flex items-center gap-2 text-xs text-slate-400">
                        <span class="w-2 h-2 rounded-full bg-[#ff2a6d] shadow-[0_0_5px_#ff2a6d]"></span> Phase T (Particle/Knot)
                    </div>
                  </div>
              </div>

              <!-- Setup -->
              <div class="bg-black/20 p-4 rounded-lg border border-slate-800">
                  <h3 class="mt-0 text-sm text-white border-b border-slate-700 pb-2 mb-4 font-semibold">Experimental Setup</h3>
                  
                  <div class="mb-4">
                    <label class="flex justify-between text-xs mb-2 text-slate-400 font-medium">
                        <span>Electron Flux</span>
                        <span class="text-physics-cyan">{{flux}}%</span>
                    </label>
                    <input type="range" min="1" max="20" [(ngModel)]="flux" class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-physics-cyan hover:accent-cyan-300 transition-colors">
                  </div>

                  <div>
                    <label class="flex justify-between text-xs mb-2 text-slate-400 font-medium">
                        <span>Slit Separation (s)</span>
                        <span class="text-physics-cyan">{{slitSep}} px</span>
                    </label>
                    <input type="range" min="20" max="100" [(ngModel)]="slitSep" class="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-physics-cyan hover:accent-cyan-300 transition-colors">
                  </div>
              </div>

              <!-- Monitoring -->
              <div class="bg-black/20 p-4 rounded-lg border border-slate-800">
                  <h3 class="mt-0 text-sm text-white border-b border-slate-700 pb-2 mb-3 font-semibold">Measurement / Collapse</h3>
                  <p class="text-[10px] text-slate-500 mb-4 leading-relaxed italic">
                      "Which-way" monitoring creates EM impedance (Γ), forcing premature collapse.
                  </p>
                  
                  <label class="flex justify-between text-xs mb-2 text-slate-400 font-medium">
                      <span>Monitoring Strength (Γ)</span>
                      <span class="text-[#ff2a6d]">{{gamma}}%</span>
                  </label>
                  <input type="range" min="0" max="100" [(ngModel)]="gamma" (input)="updateStateDesc()" class="w-full mb-3 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-[#ff2a6d] hover:accent-rose-400 transition-colors">
                  
                  <div class="flex justify-between text-[10px] font-bold tracking-wider uppercase">
                      <span class="text-physics-cyan transition-opacity duration-300" [style.opacity]="1 - gamma/100">Interference</span>
                      <span class="text-[#ff2a6d] transition-opacity duration-300" [style.opacity]="gamma/100">No Interference</span>
                  </div>
              </div>

              <div class="mt-auto pt-2">
                  <button (click)="resetScreen()" class="w-full py-3 bg-gradient-to-r from-slate-800 to-slate-700 border border-slate-600 rounded text-xs font-bold text-white hover:from-slate-700 hover:to-slate-600 transition-all uppercase tracking-widest shadow-lg hover:shadow-xl active:scale-[0.98]">
                      Clear Screen
                  </button>
              </div>

          </aside>
      </main>
    </div>
  `,
  styles: [`
    .shape-knot::before, .shape-knot::after {
        content: ''; position: absolute; width: 20px; height: 20px;
        border: 3px solid #ff2a6d; border-radius: 50%;
        box-shadow: 0 0 5px rgba(255, 42, 109, 0.4);
    }
    .shape-knot::before { top: 0; left: 0; }
    .shape-knot::after { bottom: 0; right: 0; }
    .animate-spin-slow { animation: spin 4s linear infinite; }
    @keyframes spin { 100% { transform: rotate(360deg) rotateX(45deg); } }
    
    .custom-scrollbar::-webkit-scrollbar { width: 6px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: #151922; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
  `]
})
export class SstExplorerComponent implements AfterViewInit, OnDestroy {
  @ViewChild('simCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('canvasContainer') containerRef!: ElementRef<HTMLDivElement>;
  
  // State
  flux = 5;
  slitSep = 40;
  gamma = 0;
  
  // UI Text
  stateDesc = 'Electrons propagating as delocalized Toroidal Rings (R). <b>Interference pattern visible.</b>';
  stateBorderColor = '#22d3ee'; 

  // Simulation Internals
  private ctx!: CanvasRenderingContext2D;
  private width = 0;
  private height = 0;
  private particles: SwirlString[] = []; 
  private screenHits: number[] = [];
  private frame = 0;
  private animationId = 0;

  // Constants
  private readonly WAVELENGTH = 15;
  private readonly SCREEN_X_OFFSET = 50;
  private readonly SLIT_X = 150;

  ngAfterViewInit() {
    this.ctx = this.canvasRef.nativeElement.getContext('2d')!;
    this.resize();
    
    // Start loop
    this.loop();

    // Initial desc update
    this.updateStateDesc();
  }

  ngOnDestroy() {
    cancelAnimationFrame(this.animationId);
  }

  @HostListener('window:resize')
  onResize() {
    this.resize();
  }

  resize() {
    if (this.containerRef) {
        this.width = this.containerRef.nativeElement.clientWidth;
        this.height = this.containerRef.nativeElement.clientHeight;
        this.canvasRef.nativeElement.width = this.width;
        this.canvasRef.nativeElement.height = this.height;
        // Reset histogram on resize
        this.screenHits = new Array(Math.ceil(this.height)).fill(0);
    }
  }

  resetScreen() {
      this.screenHits = new Array(Math.ceil(this.height)).fill(0);
  }

  updateStateDesc() {
      if (this.gamma < 20) {
          this.stateDesc = "Electrons propagating as delocalized Toroidal Rings (R). <b>Interference pattern visible.</b>";
          this.stateBorderColor = "#22d3ee";
      } else if (this.gamma > 80) {
          this.stateDesc = "Strong Monitoring (Γ). Premature collapse to Knotted Solitons (T). <b>Particle-like lumps.</b>";
          this.stateBorderColor = "#ff2a6d";
      } else {
          this.stateDesc = "Partial Monitoring. Mixed state ensemble. Visibility (V) degrading.";
          this.stateBorderColor = "#94a3b8";
      }
  }

  private loop() {
    this.animationId = requestAnimationFrame(() => this.loop());
    
    // Clear background
    this.ctx.fillStyle = 'rgba(11, 13, 18, 0.3)';
    this.ctx.fillRect(0, 0, this.width, this.height);

    this.drawEnvironment();

    // Spawn Particles based on flux
    // Higher flux number in UI means more particles (lower modulo)
    const spawnRate = Math.max(1, 21 - this.flux);
    if (this.frame % spawnRate === 0) {
        this.particles.push(new SwirlString(this.height, this.width, this.gamma, this.slitSep, this.WAVELENGTH, this.SLIT_X));
    }

    // Update & Draw Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
        const p = this.particles[i];
        
        // Update returns false if particle dies/hits screen
        const alive = p.update(this.width, this.SCREEN_X_OFFSET, this.SLIT_X, this.slitSep, this.screenHits);
        
        if (!alive) {
            this.particles.splice(i, 1);
        } else {
            p.draw(this.ctx);
        }
    }

    this.drawScreen();
    this.frame++;
  }

  private drawEnvironment() {
    const slitH = 40; 
    const barrierX = this.SLIT_X;
    const centerY = this.height / 2;
    const halfSep = this.slitSep / 2;

    this.ctx.fillStyle = '#334155'; // Slate 700
    
    // Top Barrier
    this.ctx.fillRect(barrierX, 0, 4, centerY - halfSep - 5);
    // Middle Barrier
    this.ctx.fillRect(barrierX, centerY - halfSep + 5, 4, this.slitSep - 10);
    // Bottom Barrier
    this.ctx.fillRect(barrierX, centerY + halfSep + 5, 4, this.height);

    // Emitter
    this.ctx.fillStyle = '#fff';
    this.ctx.beginPath();
    this.ctx.arc(20, centerY, 5, 0, Math.PI*2);
    this.ctx.fill();
    
    // Emitter Glow
    this.ctx.shadowBlur = 15;
    this.ctx.shadowColor = '#22d3ee';
    this.ctx.strokeStyle = '#22d3ee';
    this.ctx.beginPath();
    this.ctx.arc(20, centerY, 10, 0, Math.PI*2);
    this.ctx.stroke();
    this.ctx.shadowBlur = 0;
  }

  private drawScreen() {
    const screenX = this.width - this.SCREEN_X_OFFSET;
    
    // Draw the physical screen line
    this.ctx.strokeStyle = '#475569';
    this.ctx.beginPath();
    this.ctx.moveTo(screenX, 0);
    this.ctx.lineTo(screenX, this.height);
    this.ctx.stroke();

    // Draw Intensity Graph
    this.ctx.beginPath();
    this.ctx.moveTo(screenX, 0);
    
    for (let y = 0; y < this.screenHits.length; y++) {
        const intensity = this.screenHits[y];
        if (intensity > 0) this.screenHits[y] *= 0.99; // Decay
        this.ctx.lineTo(screenX + intensity, y);
    }
    
    // Gradient fill
    const grad = this.ctx.createLinearGradient(screenX, 0, this.width, 0);
    grad.addColorStop(0, 'rgba(34, 211, 238, 0.1)'); // Physics Cyan
    
    if (this.gamma > 50) {
        grad.addColorStop(1, 'rgba(255, 42, 109, 0.6)'); // Knot Color
    } else {
        grad.addColorStop(1, 'rgba(34, 211, 238, 0.6)');
    }

    this.ctx.fillStyle = grad;
    this.ctx.fill();
  }
}

// --- Particle Class ---
class SwirlString {
    x = 0;
    y = 0;
    vx = 0;
    vy = 0;
    phase: 'R' | 'T' = 'R';
    life = 0;
    color = '#22d3ee';
    targetY = 0;

    constructor(height: number, width: number, gamma: number, slitSep: number, wavelength: number, slitX: number) {
        this.y = height / 2 + (Math.random() - 0.5) * 20; 
        this.vx = 3 + Math.random(); 
        
        // Check for early collapse
        if (Math.random() * 100 < gamma) {
            this.collapseToKnot(true, height, slitSep);
        } else {
            this.targetY = this.calculateTarget(height, width, slitSep, wavelength, slitX);
        }
    }

    collapseToKnot(early: boolean, height: number, slitSep: number) {
        this.phase = 'T';
        this.color = '#ff2a6d';
        
        if (early) {
            const slit1Y = height/2 - slitSep/2;
            const slit2Y = height/2 + slitSep/2;
            const chosenSlitY = Math.random() < 0.5 ? slit1Y : slit2Y;
            
            const spread = 40; 
            const gaussian = (Math.random() + Math.random() + Math.random() - 1.5) * spread;
            this.targetY = chosenSlitY + gaussian * 2; 
        }
    }

    calculateTarget(height: number, width: number, slitSep: number, wavelength: number, slitX: number): number {
        const L = width - slitX; 
        let found = false;
        let yCandidate = height / 2;
        let safety = 0;

        while (!found && safety < 50) {
            safety++;
            yCandidate = Math.random() * height;
            const yOffset = yCandidate - height/2;
            
            // Interference Eq (14)
            const phase = (Math.PI * slitSep * yOffset) / (wavelength * L);
            const interference = Math.pow(Math.cos(phase), 2);
            const diffractionWidth = 300; 
            const envelope = Math.exp( - (yOffset*yOffset) / (diffractionWidth*diffractionWidth) );
            
            if (Math.random() < interference * envelope) {
                found = true;
            }
        }
        return yCandidate;
    }

    update(width: number, screenOffset: number, slitX: number, slitSep: number, hits: number[]): boolean {
        this.x += this.vx;
        this.life++;

        if (this.phase === 'R') {
            this.y += Math.sin(this.life * 0.2) * 0.5;
        }

        if (this.x < slitX) {
            if (this.phase === 'T') {
                const slit1Y = hits.length/2 - slitSep/2; // approximate height from hits array length
                const slit2Y = hits.length/2 + slitSep/2;
                const targetSlit = (Math.abs(this.y - slit1Y) < Math.abs(this.y - slit2Y)) ? slit1Y : slit2Y;
                this.y += (targetSlit - this.y) * 0.05;
            }
        } else {
            const progress = (this.x - slitX) / (width - screenOffset - slitX);
            if (progress >= 0 && progress <= 1) {
                let originY = hits.length/2;
                if (this.phase === 'T') {
                    originY = (this.targetY < hits.length/2) ? (hits.length/2 - slitSep/2) : (hits.length/2 + slitSep/2);
                }
                const idealY = originY + (this.targetY - originY) * progress;
                this.y += (idealY - this.y) * 0.1;
            }
        }

        if (this.x >= width - screenOffset) {
            const yIdx = Math.floor(this.y);
            if (yIdx >= 0 && yIdx < hits.length) {
                hits[yIdx] += 2; 
            }
            return false; 
        }
        return true; 
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.save();
        ctx.translate(this.x, this.y);

        if (this.phase === 'R') {
            ctx.strokeStyle = `rgba(34, 211, 238, ${1 - this.life/600})`;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            const r = 3 + Math.sin(this.life * 0.1) * 1;
            ctx.ellipse(0, 0, r, r*0.6, this.life*0.05, 0, Math.PI*2);
            ctx.stroke();
        } else {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(0, 0, 2.5, 0, Math.PI*2);
            ctx.fill();
            // Trail
            ctx.beginPath();
            ctx.moveTo(-5, 0);
            ctx.lineTo(0,0);
            ctx.strokeStyle = this.color;
            ctx.stroke();
        }
        ctx.restore();
    }
}
