import { Component, ElementRef, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import * as THREE from 'three';

@Component({
  selector: 'app-hero-scene',
  template: '<div #rendererContainer class="w-full h-full"></div>'
})
export class HeroSceneComponent implements AfterViewInit, OnDestroy {
  @ViewChild('rendererContainer') rendererContainer!: ElementRef;
  
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private animationId: number = 0;
  private torus!: THREE.Mesh;
  private particles: THREE.Mesh[] = [];

  ngAfterViewInit() {
    this.initThree();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const width = this.rendererContainer.nativeElement.clientWidth;
    const height = this.rendererContainer.nativeElement.clientHeight;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog('#020617', 5, 20);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.z = 8;

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.renderer.setSize(width, height);
    this.rendererContainer.nativeElement.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.2);
    this.scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x22d3ee, 1.5);
    pointLight.position.set(10, 10, 10);
    this.scene.add(pointLight);

    const pointLight2 = new THREE.PointLight(0xc084fc, 0.5);
    pointLight2.position.set(-10, -10, -10);
    this.scene.add(pointLight2);

    // Torus (Vortex Ring)
    const geometry = new THREE.TorusGeometry(2.5, 0.4, 30, 100);
    const material = new THREE.MeshPhysicalMaterial({
      color: 0x22d3ee,
      emissive: 0x0891b2,
      emissiveIntensity: 0.5,
      roughness: 0,
      metalness: 1,
      transparent: true,
      opacity: 0.8,
      clearcoat: 1
    });
    this.torus = new THREE.Mesh(geometry, material);
    this.torus.rotation.x = Math.PI / 3;
    this.scene.add(this.torus);

    // Particles
    const particleGeo = new THREE.SphereGeometry(0.05, 8, 8);
    for (let i = 0; i < 40; i++) {
      const mat = new THREE.MeshBasicMaterial({ 
        color: Math.random() > 0.5 ? 0x22d3ee : 0xc084fc 
      });
      const mesh = new THREE.Mesh(particleGeo, mat);
      
      mesh.position.x = (Math.random() - 0.5) * 15;
      mesh.position.y = (Math.random() - 0.5) * 10;
      mesh.position.z = (Math.random() - 0.5) * 8;
      
      this.particles.push(mesh);
      this.scene.add(mesh);
    }

    // Resize listener
    window.addEventListener('resize', () => {
      const w = this.rendererContainer.nativeElement.clientWidth;
      const h = this.rendererContainer.nativeElement.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }

  private animate() {
    this.animationId = requestAnimationFrame(() => this.animate());
    const time = Date.now() * 0.001;

    // Rotate Torus
    if (this.torus) {
      this.torus.rotation.x = (Math.PI / 3) + Math.sin(time * 0.5) * 0.1;
      this.torus.rotation.y += 0.002;
    }

    // Animate Particles
    this.particles.forEach((p, i) => {
      p.position.y += Math.sin(time + p.position.x) * 0.01;
    });

    this.renderer.render(this.scene, this.camera);
  }
}