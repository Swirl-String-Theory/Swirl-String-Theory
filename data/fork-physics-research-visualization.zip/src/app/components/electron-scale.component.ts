import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-electron-scale',
  template: `
    <div class="flex flex-col items-center p-8 bg-physics-card/50 backdrop-blur-md rounded-xl border border-slate-800 my-8 shadow-xl">
      <h3 class="font-serif text-xl mb-4 text-physics-text">Deriving the Identity</h3>
      <p class="text-sm text-physics-muted mb-6 text-center max-w-md">
        Paper 1 demonstrates how independently defined electron scales combine into a dimensionally consistent identity.
      </p>

      <div class="relative w-full max-w-lg h-48 bg-black/40 rounded-lg shadow-inner overflow-hidden mb-6 border border-slate-700/50 flex flex-col items-center justify-center p-4">
        
        <!-- Step 1 -->
        <div *ngIf="step === 0" class="animate-fade-in w-full flex gap-4 items-center justify-center">
            <div class="flex flex-col items-center">
                <div class="w-14 h-14 rounded-full bg-physics-cyan/10 border border-physics-cyan flex items-center justify-center font-serif font-bold text-physics-cyan shadow-[0_0_15px_rgba(34,211,238,0.3)]">rₑ</div>
                <span class="text-[10px] mt-2 font-bold uppercase text-physics-muted">Classical Radius</span>
            </div>
            <div class="flex flex-col items-center">
                <div class="w-14 h-14 rounded-full bg-physics-purple/10 border border-physics-purple flex items-center justify-center font-serif font-bold text-physics-purple shadow-[0_0_15px_rgba(192,132,252,0.3)]">ω꜀</div>
                <span class="text-[10px] mt-2 font-bold uppercase text-physics-muted">Compton Freq</span>
            </div>
            <div class="flex flex-col items-center">
                <div class="w-14 h-14 rounded-full bg-physics-gold/10 border border-physics-gold flex items-center justify-center font-serif font-bold text-physics-gold shadow-[0_0_15px_rgba(251,191,36,0.3)]">Eᵦ</div>
                <span class="text-[10px] mt-2 font-bold uppercase text-physics-muted">Bohr Energy</span>
            </div>
        </div>

        <!-- Step 2 -->
        <div *ngIf="step === 1" class="animate-fade-in text-center">
            <p class="font-serif italic text-lg mb-4 text-physics-text">F_max = mₑ ω_*² x_max</p>
            <p class="text-xs text-physics-muted">
                Let <span class="font-bold text-physics-purple">ω_* = ω꜀ / α</span> and <span class="font-bold text-physics-cyan">x_max = rₑ</span>
            </p>
        </div>

        <!-- Step 3 -->
        <div *ngIf="step === 2" class="animate-fade-in text-center">
            <p class="font-serif text-lg text-physics-text">
                F_max = mₑ <span class="text-slate-500">(</span> <span class="text-physics-purple font-bold">ω꜀</span>/<span class="text-slate-500">α</span> <span class="text-slate-500">)²</span> <span class="text-physics-cyan font-bold">rₑ</span>
            </p>
            <div class="mt-3 text-xs text-physics-muted">Substitute standard definitions</div>
        </div>

        <!-- Step 4 -->
        <div *ngIf="step === 3" class="animate-fade-in text-center">
            <p class="font-serif text-xl font-bold text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                F_max = mₑ² c³ / (α ħ)
            </p>
            <div class="mt-3 text-xs text-physics-muted">A unified force purely from constants</div>
        </div>

        <!-- Step 5 -->
        <div *ngIf="step === 4" class="animate-fade-in text-center p-4 bg-physics-gold/10 rounded-lg border border-physics-gold/30 shadow-[0_0_30px_rgba(251,191,36,0.1)]">
            <p class="font-serif text-2xl font-bold text-physics-gold">
                ½ mₑ c²  =  Eᵦ / α²
            </p>
            <div class="mt-2 text-xs font-bold text-physics-gold uppercase tracking-widest animate-pulse">Exact Match</div>
        </div>

      </div>

      <!-- Steps Indicator -->
      <div class="flex gap-2 justify-center w-full">
          <div *ngFor="let s of steps; let i = index" class="h-1 rounded-full transition-all duration-300" 
            [ngClass]="step === i ? 'w-8 bg-physics-cyan shadow-[0_0_10px_#22d3ee]' : 'w-2 bg-slate-700'">
          </div>
      </div>
      <div class="mt-3 text-xs font-bold uppercase tracking-wider text-physics-cyan">
          Step {{step + 1}}: {{steps[step]}}
      </div>
    </div>
  `
})
export class ElectronScaleComponent implements OnInit, OnDestroy {
  step = 0;
  steps = ["The Ingredients", "Harmonic Oscillator Ansatz", "Combine Constants", "Resulting Force Scale", "The Energy Identity"];
  private intervalId: any;

  ngOnInit() {
    this.intervalId = setInterval(() => {
        this.step = (this.step + 1) % 5;
    }, 4000);
  }

  ngOnDestroy() {
    if (this.intervalId) clearInterval(this.intervalId);
  }
}