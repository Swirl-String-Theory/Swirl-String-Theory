import { Component, ElementRef, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import * as THREE from 'three';

@Component({
  selector: 'app-fluid-scene',
  template: '<div #rendererContainer class="w-full h-full rounded-2xl overflow-hidden"></div>'
})
export class FluidSceneComponent implements AfterViewInit, OnDestroy {
  @ViewChild('rendererContainer') rendererContainer!: ElementRef;
  
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private animationId: number = 0;
  private particles: { mesh: THREE.Mesh, angle: number, radius: number, speed: number }[] = [];

  ngAfterViewInit() {
    this.initThree();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
  }

  private initThree() {
    const width = this.rendererContainer.nativeElement.clientWidth;
    const height = this.rendererContainer.nativeElement.clientHeight;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#0f172a');

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 2, 5);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(width, height);
    this.rendererContainer.nativeElement.appendChild(this.renderer.domElement);

    // Lighting
    const spotLight = new THREE.SpotLight(0x22d3ee, 2);
    spotLight.position.set(5, 10, 5);
    this.scene.add(spotLight);
    
    const ambient = new THREE.AmbientLight(0xffffff, 0.5);
    this.scene.add(ambient);

    // Cylinder Container
    const cylinderGeo = new THREE.CylinderGeometry(1.5, 1.5, 3, 32);
    const cylinderMat = new THREE.MeshPhysicalMaterial({
      color: 0x94a3b8,
      transmission: 0.9,
      opacity: 1,
      transparent: true,
      roughness: 0,
      ior: 1.5,
      thickness: 0.5
    });
    const cylinder = new THREE.Mesh(cylinderGeo, cylinderMat);
    cylinder.position.y = 1.5;
    this.scene.add(cylinder);

    // Swirling Particles
    const pGeo = new THREE.SphereGeometry(0.08, 8, 8);
    for(let i=0; i<50; i++) {
        const color = i % 2 === 0 ? 0xfbbf24 : 0x22d3ee;
        const mat = new THREE.MeshStandardMaterial({ color: color, emissive: color, emissiveIntensity: 1 });
        const mesh = new THREE.Mesh(pGeo, mat);
        
        const radius = 0.5 + Math.random() * 0.8;
        const angle = Math.random() * Math.PI * 2;
        const y = 0.5 + Math.random() * 2;
        
        mesh.position.set(radius * Math.cos(angle), y, radius * Math.sin(angle));
        this.scene.add(mesh);
        
        this.particles.push({ mesh, angle, radius, speed: 0.02 + Math.random() * 0.03 });
    }
  }

  private animate() {
    this.animationId = requestAnimationFrame(() => this.animate());
    
    this.particles.forEach(p => {
        p.angle += p.speed;
        p.mesh.position.x = p.radius * Math.cos(p.angle);
        p.mesh.position.z = p.radius * Math.sin(p.angle);
    });

    this.renderer.render(this.scene, this.camera);
  }
}