import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-energy-chart',
  template: `
    <div class="flex flex-col md:flex-row gap-8 items-center p-8 bg-gradient-to-br from-physics-card to-slate-950 rounded-xl my-8 border border-slate-800 shadow-2xl relative overflow-hidden">
        <!-- Background Accent -->
        <div class="absolute top-0 right-0 w-64 h-64 bg-physics-purple/10 blur-[80px] rounded-full pointer-events-none"></div>

        <div class="flex-1 min-w-[240px] z-10">
            <h3 class="font-serif text-2xl mb-3 text-white">Numerical Precision</h3>
            <p class="text-physics-muted text-sm mb-6 leading-relaxed">
                Paper 1 confirms the analytical identity numerically using CODATA values. The "Half Rest Energy" of the electron matches the "Scaled Hydrogen Ground State" to within numerical precision.
            </p>
            <div class="p-4 bg-black/30 rounded border border-slate-700 font-mono text-xs space-y-3">
                <div class="flex justify-between items-center">
                    <span class="text-physics-muted">mₑc²</span>
                    <span class="text-physics-cyan">≈ 511 keV</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-physics-muted">E_B</span>
                    <span class="text-physics-gold">≈ 13.6 eV</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-physics-muted">α⁻¹</span>
                    <span class="text-physics-purple">≈ 137.036</span>
                </div>
            </div>
        </div>
        
        <div class="relative w-64 h-64 bg-black/40 rounded-xl border border-slate-700 p-6 flex justify-around items-end z-10 backdrop-blur-sm">
            <!-- Background Grid Lines -->
            <div class="absolute inset-0 p-6 flex flex-col justify-between pointer-events-none opacity-20">
                <div class="w-full h-[1px] bg-slate-500"></div>
                <div class="w-full h-[1px] bg-slate-500"></div>
                <div class="w-full h-[1px] bg-slate-500"></div>
                <div class="w-full h-[1px] bg-slate-500"></div>
            </div>

            <!-- Bar 1 -->
            <div class="w-20 flex flex-col justify-end items-center h-full z-10">
                <div class="flex-1 w-full flex items-end justify-center relative mb-3">
                    <div class="absolute -top-8 w-full text-center text-[10px] font-mono text-physics-cyan">255.5 keV</div>
                    <div class="w-full bg-gradient-to-t from-physics-cyan/20 to-physics-cyan rounded-t-sm shadow-[0_0_15px_rgba(34,211,238,0.4)] transition-all duration-1000 ease-out"
                         [style.height]="loaded ? '80%' : '0%'"></div>
                </div>
                <div class="h-10 flex flex-col items-center justify-center text-[10px] font-bold text-physics-muted uppercase tracking-wider text-center">
                    <span class="text-white">½ mₑc²</span>
                    <span class="font-normal opacity-50 text-[8px] scale-90">Relativistic</span>
                </div>
            </div>

            <!-- Bar 2 -->
            <div class="w-20 flex flex-col justify-end items-center h-full z-10">
                    <div class="flex-1 w-full flex items-end justify-center relative mb-3">
                    <div class="absolute -top-8 w-full text-center text-[10px] font-mono text-physics-gold font-bold">255.5 keV</div>
                    <div class="w-full bg-gradient-to-t from-physics-gold/20 to-physics-gold rounded-t-sm shadow-[0_0_20px_rgba(251,191,36,0.5)] relative overflow-hidden transition-all duration-1000 ease-out delay-300"
                        [style.height]="loaded ? '80%' : '0%'">
                        <div class="absolute inset-0 bg-white/20"></div>
                    </div>
                </div>
                    <div class="h-10 flex flex-col items-center justify-center text-[10px] font-bold text-physics-muted uppercase tracking-wider text-center">
                    <span class="text-white">Eᵦ / α²</span>
                    <span class="font-normal opacity-50 text-[8px] scale-90">Atomic</span>
                    </div>
            </div>
        </div>
    </div>
  `
})
export class EnergyChartComponent implements AfterViewInit {
  loaded = false;

  ngAfterViewInit() {
    // Simple delay to trigger animation
    setTimeout(() => {
        this.loaded = true;
    }, 500);
  }
}