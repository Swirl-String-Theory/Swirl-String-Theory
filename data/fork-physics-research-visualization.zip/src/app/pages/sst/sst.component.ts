import {Component, ElementRef, Input, OnChanges, OnDestroy, OnInit, SimpleChange, SimpleChanges, ViewChild} from '@angular/core';
import {
  Config,
  IonRouterOutlet,
  LoadingController,
  PopoverController
} from "@ionic/angular";

import {NavigationEnd, Router} from "@angular/router";
import {StorageService} from "../../services/storage.service";
import {AccountPage, User} from "../account/account";
import { Storage } from '@ionic/storage-angular';
import { Renderer2} from '@angular/core';
import "jquery";
import {SstPopoverPage} from "./sst-popover";
import {
  AlertController,
  ModalController,
  ToastController
} from "@ionic/angular";
import {Element} from "@angular/compiler";

import {GetResult} from "@capacitor/preferences";
import {ConferenceData} from "../../providers/conference-data";

import {UserData} from "../../providers/user-data";
import Echo from './echo-plugin';

declare var $: any;
declare var jQuery: any;


@Component({
  selector: 'app-sst',
  templateUrl: './sst.component.html',
  styleUrls: ['./sst.component.scss']
})
export class SstComponent implements OnInit, OnChanges, OnDestroy {
  static hideIframe: string;
  @Input() sstdata: User[]=  [];
  all: any;
  routerSubscription: any;


  constructor(
    public popoverCtrl: PopoverController,
    public loadingCtrl: LoadingController,
    public storageServive: StorageService,
    public router: Router,
    public routerOutlet: IonRouterOutlet,
    public config: Config,
    private renderer: Renderer2,
    public alertCtrl: AlertController,
    public confData: ConferenceData,
    public modalCtrl: ModalController,
    public toastCtrl: ToastController,
    public user: UserData,

  ) { }

  // This lifecycle method will be triggered when the Home page becomes active
  ionViewWillEnter() {
    this.refreshData(); // Replace this with your data-fetching or refreshing logic
  }

  refreshData() {
    this.getJson();
  }

  toggle($event: User) {
    this.sstdata.find(value => {
      if (value.ipAddress === $event.ipAddress) value.hide = !value.hide;
    })
    console.log("$event: ", $event);
  }

  async getJson() {
      await this.storageServive.getData("SST").then((data:any) => {
        let res: User[];
          res = JSON.parse(data.value);
          this.sstdata = res
        console.log("%c 2 --> 73||C:/workspace/projects/SST-Android/src/app/pages/sst/sst.component.ts\n this.sstdata: ","color:#0f0;", this.sstdata);
      });
  }

  ngOnInit(): void {
    this.getJson();
  }

  // This method will be triggered whenever @Input() properties change
  ngOnChanges(changes: SimpleChanges) {
    console.log('Changes detected:', changes);

    // Check if a specific property changed
    if (changes['sstdata']) {
      const previousValue = changes['sstdata'].previousValue;
      const currentValue = changes['sstdata'].currentValue;
      console.log(`inputProp changed from ${previousValue} to ${currentValue}`);

    }
  }

  ngOnDestroy(): void {
    // Unsubscribe to avoid memory leaks

  }

  getPcName(buttenName: string): string {
    const pcMatch = buttenName.match(/\d+\.\d+\.\d+\.(\d+)/);  // Matches the last octet
    const portMatch = buttenName.match(/:(\d{4})/);  // Matches the first two digits of the port (81)
// Extract values if matches are found
    const pc = pcMatch ? pcMatch[1] : null;
    const port = portMatch ? portMatch[1].slice(-2) : null;

    let matchedText;
    if (pc && port) {
      matchedText = pc + ': ' + port;
    }
    return matchedText;
  }

  async presentPopover(event: Event) {
    const popover = await this.popoverCtrl.create({
      component: SstPopoverPage,
      event
    });
    await popover.present();
  }
}