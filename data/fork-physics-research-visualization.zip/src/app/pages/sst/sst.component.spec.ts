import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SstComponent } from './sst.component';

declare var describe: any;
declare var beforeEach: any;
declare var it: any;
declare var expect: any;

describe('SstComponent', () => {
  let component: SstComponent;
  let fixture: ComponentFixture<SstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SstComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});