import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';


import { SstComponent } from './sst.component';
import { SstRoutingModule } from './sst-routing.module';
import { SstPopoverPage } from './sst-popover';
import {HexatrailComponent} from "../../hexatrail/hexatrail.component";
import {AccountModule} from "../account/account.module";

import {IframeComponent} from "../../iframe/iframe.component";
import {IFrameToggler} from "../../iframe/iframe-toggler.component";






@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    SstRoutingModule,
    FormsModule,
    IonicModule,
    IonicModule,
    HexatrailComponent,
    AccountModule,
    IframeComponent,
    IFrameToggler,
  ],
  declarations: [
    SstComponent, SstPopoverPage
  ],
  bootstrap: [SstComponent]
})
export class SstModule { }
