
export interface UserOptions {
  username: string;
  password: string;
  sstpassword: string;
  ipaddress: string;

}
