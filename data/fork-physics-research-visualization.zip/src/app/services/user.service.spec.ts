import { TestBed } from '@angular/core/testing';

import { UserService } from './user.service';

declare var describe: any;
declare var beforeEach: any;
declare var it: any;
declare var expect: any;

describe('UserService', () => {
  let service: UserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});