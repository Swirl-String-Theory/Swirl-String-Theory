import { TestBed } from '@angular/core/testing';

import { StorageService } from './storage.service';

declare var describe: any;
declare var beforeEach: any;
declare var it: any;
declare var expect: any;

describe('StorageService', () => {
  let service: StorageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StorageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});