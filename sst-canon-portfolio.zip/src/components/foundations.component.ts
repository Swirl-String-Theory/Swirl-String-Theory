import { Component, inject } from '@angular/core';
import { SstDataService } from '../services/sst-data.service';
import { KatexComponent } from './katex.component';

@Component({
  selector: 'app-foundations',
  standalone: true,
  imports: [KatexComponent],
  template: `
    <div class="p-6 md:p-10 max-w-6xl mx-auto h-full overflow-y-auto">
      <header class="mb-10 border-b border-slate-800 pb-4">
        <h2 class="text-3xl font-bold text-white mb-2">Core Axioms</h2>
        <p class="text-slate-400">Part II: Foundations & Sevenfold Genesis of the Swirling Cosmos</p>
      </header>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @for (axiom of sst.axioms(); track axiom.id) {
          <div class="glass-panel p-6 rounded-xl flex flex-col hover:border-cyan-700/50 transition-colors group">
            <div class="flex items-center justify-between mb-4">
              <span class="text-5xl font-black text-slate-800 group-hover:text-slate-700 transition-colors select-none">
                {{ axiom.id }}
              </span>
              <div class="w-2 h-2 rounded-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.6)]"></div>
            </div>
            
            <h3 class="text-xl font-bold text-cyan-100 mb-3">{{ axiom.title }}</h3>
            
            <p class="text-slate-400 text-sm leading-relaxed mb-4 flex-grow">
              {{ axiom.description }}
            </p>

            @if (axiom.latex) {
              <div class="mt-auto pt-4 border-t border-slate-700/50">
                <app-katex [expression]="axiom.latex" [isBlock]="false" />
              </div>
            }
          </div>
        }
      </div>

      <div class="mt-12 p-8 bg-slate-900 rounded-xl border-l-4 border-amber-500">
        <h3 class="text-lg font-bold text-amber-500 mb-2">Preface: Reader Pathways</h3>
        <p class="text-slate-300 text-sm leading-relaxed">
          Beginner-level readers are encouraged to focus on the physical descriptions and boxed highlights.
          Expert readers can delve into detailed derivations in the appendices. The goal is to reinterpret 
          modern physics in terms of an incompressible vacuum fluid (ether), where forces are accelerations 
          and particles are knots.
        </p>
      </div>
    </div>
  `
})
export class FoundationsComponent {
  sst = inject(SstDataService);
}