import { Component, ElementRef, input, effect, viewChild } from '@angular/core';

declare const katex: any;

@Component({
  selector: 'app-katex',
  standalone: true,
  template: `
    <div #container class="katex-container overflow-x-auto overflow-y-hidden py-2 text-slate-200"></div>
  `,
  styles: [`
    .katex-container { min-height: 2em; }
    :host { display: block; }
  `]
})
export class KatexComponent {
  expression = input.required<string>();
  isBlock = input<boolean>(false);

  containerRef = viewChild.required<ElementRef<HTMLDivElement>>('container');

  constructor() {
    effect((onCleanup) => {
      const expr = this.expression();
      const block = this.isBlock();
      const container = this.containerRef();
      const el = container?.nativeElement;
      
      let retryTimer: any;

      const render = () => {
        if (!el) return;

        if (typeof katex !== 'undefined') {
          try {
            katex.render(expr, el, {
              displayMode: block,
              throwOnError: false,
              errorColor: '#f87171' // Light red for errors
            });
          } catch (e) {
            el.innerText = expr;
            console.warn('KaTeX render error', e);
          }
        } else {
          // If katex is not loaded yet, retry shortly
          retryTimer = setTimeout(render, 100);
        }
      };

      render();

      onCleanup(() => {
        if (retryTimer) clearTimeout(retryTimer);
      });
    });
  }
}