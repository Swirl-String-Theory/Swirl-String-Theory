import { Component, inject } from '@angular/core';
import { SstDataService } from '../services/sst-data.service';
import { KatexComponent } from './katex.component';

@Component({
  selector: 'app-theory',
  standalone: true,
  imports: [KatexComponent],
  template: `
    <div class="p-6 md:p-10 max-w-7xl mx-auto h-full overflow-y-auto">
      
      <header class="mb-8">
        <h2 class="text-3xl font-bold text-white mb-2">Geometry, Fields, & Lagrangian</h2>
        <p class="text-slate-400">Part III: Formal Structure and Canonical Framework</p>
      </header>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        <!-- Left Col: Equations -->
        <div class="space-y-6">
          <h3 class="text-xl font-semibold text-cyan-400 border-b border-slate-800 pb-2">Master Equations</h3>
          
          @for (eq of sst.equations(); track eq.name) {
            <div class="glass-panel p-6 rounded-lg border border-slate-700">
              <div class="text-sm text-slate-400 mb-3 uppercase tracking-wider">{{ eq.name }}</div>
              <div class="bg-slate-950/50 p-4 rounded-md border border-slate-800 flex justify-center">
                <app-katex [expression]="eq.latex" [isBlock]="true" />
              </div>
            </div>
          }
        </div>

        <!-- Right Col: Constants -->
        <div class="space-y-6">
          <h3 class="text-xl font-semibold text-amber-400 border-b border-slate-800 pb-2">Canonical Constants</h3>
          
          <div class="overflow-hidden rounded-lg border border-slate-800">
            <table class="w-full text-left text-sm">
              <thead class="bg-slate-900 text-slate-300 font-medium">
                <tr>
                  <th class="px-4 py-3">Symbol</th>
                  <th class="px-4 py-3">Definition</th>
                  <th class="px-4 py-3">Value / Relation</th>
                  <th class="px-4 py-3 text-right">Type</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800 bg-slate-900/40">
                @for (const of sst.constants(); track const.symbol) {
                  <tr class="hover:bg-slate-800/30 transition-colors">
                    <td class="px-4 py-3 font-serif text-cyan-300">
                      <app-katex [expression]="const.symbol" />
                    </td>
                    <td class="px-4 py-3 text-slate-300">{{ const.name }}</td>
                    <td class="px-4 py-3 text-slate-400 font-mono text-xs">
                      @if (const.latexValue) {
                        <app-katex [expression]="const.latexValue" />
                      } @else {
                        {{ const.value }}
                      }
                    </td>
                    <td class="px-4 py-3 text-right">
                      <span [class]="getTypeClass(const.type) + ' px-2 py-0.5 rounded text-[10px] font-bold uppercase'">
                        {{ const.type }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <div class="p-6 bg-amber-900/10 border border-amber-900/30 rounded-lg">
            <h4 class="text-amber-500 font-bold mb-2">Zero-Parameter Principle</h4>
            <p class="text-sm text-amber-200/80 leading-relaxed">
              All dimensional constants of nature are determined by the condensate state, its circulation quantum, 
              and allowed topological sectors. The primitive triplet is <app-katex expression="(\\Gamma_0, \\rho_f, r_c)" />.
            </p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    td { vertical-align: middle; }
  `]
})
export class TheoryComponent {
  sst = inject(SstDataService);

  getTypeClass(type: string): string {
    switch(type) {
      case 'Primitive': return 'bg-cyan-900 text-cyan-300';
      case 'Derived': return 'bg-purple-900 text-purple-300';
      default: return 'bg-slate-700 text-slate-300';
    }
  }
}