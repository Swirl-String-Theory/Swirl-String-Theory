import { Component } from '@angular/core';
import { KatexComponent } from './katex.component';

@Component({
  selector: 'app-cosmology',
  standalone: true,
  imports: [KatexComponent],
  template: `
    <div class="p-6 md:p-10 max-w-4xl mx-auto h-full overflow-y-auto">
      
      <div class="mb-12 text-center">
        <h1 class="text-4xl font-extrabold text-white mb-4">Gravity & Cosmology</h1>
        <div class="h-1 w-20 bg-gradient-to-r from-cyan-500 to-blue-600 mx-auto rounded-full"></div>
      </div>

      <section class="mb-12">
        <h2 class="text-2xl font-bold text-cyan-200 mb-4">Swirl-Based Gravitation</h2>
        <p class="text-slate-300 leading-relaxed mb-6">
          Newtonian gravity is not primitive. In SST, <span class="text-amber-400 font-mono">G_swirl</span> 
          is an emergent coupling determined by the microscopic structure of the swirl condensate.
        </p>

        <div class="bg-slate-900 p-6 rounded-xl border border-slate-700 mb-6 shadow-lg">
          <div class="flex flex-col items-center justify-center space-y-4">
             <app-katex expression="G_{swirl} = \frac{||\mathbf{v}_\circlearrowleft|| c^5 t_p^2}{2 F_{max} r_c^2} \approx G_N" [isBlock]="true" />
          </div>
          <div class="mt-4 text-center text-sm text-slate-500">
            Connecting swirl constants to Newton's gravitational constant G<sub>N</sub>.
          </div>
        </div>
      </section>

      <section class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div>
          <h3 class="text-xl font-bold text-white mb-3">Hydrogen Mechanism</h3>
          <p class="text-slate-400 text-sm leading-relaxed mb-4">
             The hydrogen atom is a knotted swirl string (proton core) surrounded by an irrotational envelope.
             The "Spherical Pressure Boundary" creates the electron cloud.
          </p>
          <ul class="list-disc pl-5 text-sm text-slate-300 space-y-2">
            <li>Proton = Trefoil core</li>
            <li>Electron = Torus knot (3₁)</li>
            <li>Forces = Pressure equilibrium</li>
          </ul>
        </div>
        <div>
           <h3 class="text-xl font-bold text-white mb-3">Swirl Clocks</h3>
           <p class="text-slate-400 text-sm leading-relaxed mb-4">
             Time is local. A clock comoving with a swirl string ticks slower.
           </p>
           <div class="bg-slate-800/50 p-4 rounded-lg border-l-2 border-cyan-500">
             <app-katex expression="\frac{dt_{local}}{dt_{\infty}} = \sqrt{1 - \frac{||\mathbf{v}_\circlearrowleft||^2}{c^2}}" [isBlock]="true" />
           </div>
        </div>
      </section>

      <section class="bg-gradient-to-br from-indigo-900/20 to-slate-900/40 p-8 rounded-2xl border border-indigo-500/20">
        <h2 class="text-2xl font-bold text-indigo-300 mb-4">Cosmological Implications</h2>
        <p class="text-slate-300 mb-4">
           The universe is a "Swirl Condensate". Motion relative to the swirl frame produces measurable anisotropy. 
           The theory predicts a finite-topology foliation (e.g., Genus-2 Swirl Quantization).
        </p>
        <p class="text-slate-400 text-sm italic">
           "What we perceive as gravity is a statistical effect of many swirl strings and their pressure fields rather than a fundamental spacetime curvature."
        </p>
      </section>

    </div>
  `
})
export class CosmologyComponent {}