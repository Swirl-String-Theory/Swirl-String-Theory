import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-visualizer',
  standalone: true,
  template: `
    <div class="relative w-full h-full flex items-center justify-center overflow-hidden bg-slate-900 rounded-xl border border-slate-700 shadow-inner">
      <div #chartContainer class="w-full h-full"></div>
      <div class="absolute bottom-4 left-4 text-xs text-slate-400 font-mono">
        Fig 1. Conceptual Trefoil Swirl Field
      </div>
    </div>
  `
})
export class VisualizerComponent implements AfterViewInit, OnDestroy {
  @ViewChild('chartContainer') chartContainer!: ElementRef;
  private animationId: any;

  ngAfterViewInit() {
    this.initSwirlViz();
  }

  ngOnDestroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
  }

  initSwirlViz() {
    const element = this.chartContainer.nativeElement;
    const width = element.offsetWidth || 400;
    const height = element.offsetHeight || 300;

    // Clear previous
    d3.select(element).selectAll('*').remove();

    const canvas = d3.select(element)
      .append('canvas')
      .attr('width', width)
      .attr('height', height)
      .node();

    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    const centerX = width / 2;
    const centerY = height / 2;
    const scale = Math.min(width, height) / 4;

    let time = 0;

    const draw = () => {
      time += 0.015;
      context.clearRect(0, 0, width, height);
      
      // Draw background faint flow lines
      context.lineWidth = 1;
      
      // Simulate a Torus Knot (Trefoil) projection
      // Parametric equations for a Trefoil
      const p = 2;
      const q = 3;
      
      // Draw the "Swirl" particles
      const particles = 60;
      for (let i = 0; i < particles; i++) {
        const offset = (i / particles) * Math.PI * 2;
        const t = time + offset;
        
        // Torus knot equation
        const r = Math.sin(q * t) + 2;
        const x = scale * r * Math.cos(p * t);
        const y = scale * r * Math.sin(p * t);

        // Add 3D-ish rotation effect
        const rotX = x * Math.cos(time * 0.2) - y * Math.sin(time * 0.2);
        const rotY = x * Math.sin(time * 0.2) + y * Math.cos(time * 0.2);

        // Draw particle (The "String")
        context.beginPath();
        context.arc(centerX + rotX, centerY + rotY, 3, 0, 2 * Math.PI);
        context.fillStyle = `rgba(14, 165, 233, ${0.6 + 0.4 * Math.sin(t * 3)})`; // Cyan-500
        context.fill();

        // Draw "Swirl" vectors (velocity field hint)
        const vX = -rotY * 0.2;
        const vY = rotX * 0.2;
        
        context.beginPath();
        context.moveTo(centerX + rotX, centerY + rotY);
        context.lineTo(centerX + rotX + vX, centerY + rotY + vY);
        context.strokeStyle = `rgba(245, 158, 11, 0.3)`; // Amber for flow
        context.stroke();
      }

      // Draw Core Halo
      const gradient = context.createRadialGradient(centerX, centerY, scale * 0.5, centerX, centerY, scale * 2.5);
      gradient.addColorStop(0, 'rgba(14, 165, 233, 0.05)');
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      context.fillStyle = gradient;
      context.fillRect(0, 0, width, height);

      this.animationId = requestAnimationFrame(draw);
    };

    draw();
  }
}