import { Component, inject } from '@angular/core';
import { VisualizerComponent } from './visualizer.component';
import { SstDataService } from '../services/sst-data.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [VisualizerComponent, RouterLink],
  template: `
    <div class="h-full flex flex-col md:flex-row gap-6 p-6 overflow-y-auto">
      
      <!-- Hero Text Section -->
      <div class="flex-1 flex flex-col justify-center space-y-6">
        <div>
          <span class="inline-block px-3 py-1 mb-4 text-xs font-bold tracking-wider text-cyan-400 uppercase bg-cyan-900/30 rounded-full border border-cyan-800">
            Canon {{ sst.version() }}
          </span>
          <h1 class="text-4xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-100 to-slate-400">
            Swirl String Theory
          </h1>
          <h2 class="text-xl md:text-2xl text-amber-500 font-light mt-2">
            The Hydrodynamic Vacuum Canon
          </h2>
        </div>

        <p class="text-lg text-slate-300 leading-relaxed max-w-2xl">
          A fundamental re-imagining of physics where the vacuum is a frictionless, incompressible fluid. 
          Particles are knotted vortex filaments, and forces are emergent pressure gradients.
        </p>

        <div class="flex flex-wrap gap-4">
          <a routerLink="/foundations" class="px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-lg transition-all shadow-lg shadow-cyan-900/20">
            Explore Foundations
          </a>
          <a routerLink="/theory" class="px-6 py-3 border border-slate-600 hover:border-slate-400 text-slate-300 hover:text-white font-semibold rounded-lg transition-all">
            View Equations
          </a>
        </div>

        <div class="grid grid-cols-2 gap-4 mt-8">
          <div class="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
            <div class="text-2xl font-bold text-slate-100">R³</div>
            <div class="text-sm text-slate-400">Absolute Space</div>
          </div>
          <div class="p-4 rounded-lg bg-slate-900/50 border border-slate-800">
            <div class="text-2xl font-bold text-amber-500">Γ = nΓ₀</div>
            <div class="text-sm text-slate-400">Quantized Circulation</div>
          </div>
        </div>
      </div>

      <!-- Visualization Section -->
      <div class="flex-1 min-h-[300px] md:min-h-full">
        <app-visualizer />
      </div>

    </div>
  `
})
export class HomeComponent {
  sst = inject(SstDataService);
}