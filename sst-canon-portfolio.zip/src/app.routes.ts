import { Routes } from '@angular/router';
import { HomeComponent } from './components/home.component';
import { FoundationsComponent } from './components/foundations.component';
import { TheoryComponent } from './components/theory.component';
import { CosmologyComponent } from './components/cosmology.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'foundations', component: FoundationsComponent },
  { path: 'theory', component: TheoryComponent },
  { path: 'cosmology', component: CosmologyComponent },
  { path: '**', redirectTo: '' }
];