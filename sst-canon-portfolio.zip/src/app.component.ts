import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="flex h-screen w-full bg-slate-950 text-slate-200">
      
      <!-- Sidebar / Navigation -->
      <nav class="w-20 lg:w-64 flex-shrink-0 border-r border-slate-800 bg-slate-950 flex flex-col justify-between z-10">
        
        <div class="flex flex-col">
          <!-- Logo Area -->
          <div class="h-20 flex items-center justify-center border-b border-slate-800">
            <div class="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center shadow-[0_0_15px_rgba(8,145,178,0.5)]">
              <span class="font-bold text-white text-lg">S</span>
            </div>
            <span class="ml-3 font-bold text-xl tracking-tight hidden lg:block text-slate-100">SST Canon</span>
          </div>

          <!-- Links -->
          <div class="flex flex-col gap-2 p-4">
            <a routerLink="/" 
               routerLinkActive="bg-slate-800 text-cyan-400" 
               [routerLinkActiveOptions]="{exact: true}"
               class="flex items-center p-3 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 transition-all group">
               <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
               </svg>
               <span class="ml-3 font-medium hidden lg:block">Overview</span>
            </a>

            <a routerLink="/foundations" 
               routerLinkActive="bg-slate-800 text-cyan-400" 
               class="flex items-center p-3 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 transition-all group">
               <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
               </svg>
               <span class="ml-3 font-medium hidden lg:block">Foundations</span>
            </a>

            <a routerLink="/theory" 
               routerLinkActive="bg-slate-800 text-cyan-400" 
               class="flex items-center p-3 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 transition-all group">
               <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
               </svg>
               <span class="ml-3 font-medium hidden lg:block">Master Eqns</span>
            </a>

            <a routerLink="/cosmology" 
               routerLinkActive="bg-slate-800 text-cyan-400" 
               class="flex items-center p-3 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 transition-all group">
               <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
               </svg>
               <span class="ml-3 font-medium hidden lg:block">Cosmology</span>
            </a>
          </div>
        </div>

        <!-- Footer -->
        <div class="p-4 border-t border-slate-800 text-center lg:text-left">
          <div class="text-[10px] text-slate-500 font-mono">
            <span class="hidden lg:inline">Authored by</span><br class="hidden lg:inline" />
            <span class="font-bold text-slate-400">O. Iskandarani</span>
          </div>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="flex-1 relative overflow-hidden bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
        <!-- Ambient Background Glow -->
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-900/10 rounded-full blur-[100px] pointer-events-none"></div>
        <div class="absolute bottom-0 left-0 w-[400px] h-[400px] bg-amber-900/5 rounded-full blur-[80px] pointer-events-none"></div>
        
        <router-outlet></router-outlet>
      </main>

    </div>
  `
})
export class AppComponent {}