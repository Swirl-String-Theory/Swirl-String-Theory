import { Injectable, signal } from '@angular/core';

export interface Axiom {
  id: number;
  title: string;
  description: string;
  latex?: string;
}

export interface Constant {
  symbol: string;
  name: string;
  value: string;
  latexValue?: string;
  type: 'Primitive' | 'Derived' | 'Physical';
}

@Injectable({
  providedIn: 'root'
})
export class SstDataService {

  readonly version = signal('v0.6.0');

  readonly axioms = signal<Axiom[]>([
    {
      id: 1,
      title: 'Swirl Medium (Absolute Space-Time)',
      description: 'Physics is formulated on R3 with absolute reference time. Dynamics occur in a frictionless, incompressible swirl condensate which serves as a universal substrate.',
    },
    {
      id: 2,
      title: 'Swirl Strings (Circulation and Topology)',
      description: 'Particles correspond to closed vortex filaments. Circulation is quantized.',
      latex: '\\Gamma = \\oint_C \\mathbf{v}_{\\circlearrowleft} \\cdot d\\ell = n \\Gamma_0, \\quad n \\in \\mathbb{Z}'
    },
    {
      id: 3,
      title: 'String-induced Gravitation',
      description: 'Macroscopic attraction emerges from coherent swirl flows and pressure gradients. Gravity is a statistical effect of pressure fields.',
    },
    {
      id: 4,
      title: 'Swirl Clocks (Local Time Dilation)',
      description: 'Local proper-time rate depends on tangential swirl speed v. High swirl velocity causes time dilation.',
      latex: 'S_t = \\sqrt{1 - \\frac{v^2}{c^2}}'
    },
    {
      id: 5,
      title: 'Dual Phases (Wave-Particle)',
      description: 'R-phase (unknotted, wave-like, radiative) and T-phase (knotted, particle-like). Measurement is a dynamical transition between phases.'
    },
    {
      id: 6,
      title: 'Taxonomy',
      description: 'Unknotted excitations are Bosons (photons as torsional R-phase). Torus knots are Leptons (Electron = 3_1). Chiral hyperbolic knots are Quarks.'
    }
  ]);

  readonly constants = signal<Constant[]>([
    {
      symbol: '\\Gamma_0',
      name: 'Primitive Circulation Quantum',
      value: '6.4 × 10³ m²/s',
      type: 'Primitive'
    },
    {
      symbol: 'r_c',
      name: 'Swirl String Core Radius',
      value: '1.40897017 × 10⁻¹⁵ m',
      type: 'Primitive'
    },
    {
      symbol: '\\rho_f',
      name: 'Effective Fluid Density',
      value: '7.0 × 10⁻⁷ kg m⁻³',
      type: 'Primitive'
    },
    {
      symbol: '\\mathbf{v}_{\\circlearrowleft}',
      name: 'Canonical Swirl Speed',
      value: '1.09384563 × 10⁶ m s⁻¹',
      type: 'Derived'
    },
    {
      symbol: '\\rho_m',
      name: 'Mass-Equivalent Density',
      value: '3.89 × 10¹⁸ kg m⁻³',
      latexValue: '\\rho_E / c^2',
      type: 'Derived'
    },
    {
      symbol: '\\Lambda',
      name: 'Swirl Coulomb Constant',
      value: 'Hydrogenic Potential Strength',
      latexValue: '4\\pi \\rho_m \\mathbf{v}_{\\circlearrowleft} r_c^3',
      type: 'Derived'
    },
    {
      symbol: 'G_{swirl}',
      name: 'Gravitational Coupling',
      value: '≈ G_N',
      latexValue: '\\frac{\\mathbf{v}_{\\circlearrowleft} c^5 t_p^2}{2 F_{max} r_c^2}',
      type: 'Derived'
    }
  ]);

  readonly equations = signal([
    {
      name: 'Chronos-Kelvin Invariant',
      latex: '\\frac{D}{Dt}(R^2 \\omega) = 0'
    },
    {
      name: 'Swirl Pressure Law',
      latex: '\\frac{dp_{swirl}}{dr} = \\rho_f \\frac{v_{\\theta}^2}{r}'
    },
    {
      name: 'Hamiltonian Density',
      latex: '\\mathcal{H}_{SST} = \\frac{1}{2}\\rho_f \\lVert\\mathbf{v}_{\\circlearrowleft}\\rVert^2 + \\frac{1}{2}\\rho_f r_c^2 \\lVert\\omega\\rVert^2 + \\lambda(\\nabla \\cdot \\mathbf{v}_{\\circlearrowleft})'
    },
    {
      name: 'Swirl-Gravity Coupling',
      latex: 'G_{swirl} = \\frac{v}{2 F_{EM}^{max} r_c^2} \\approx G_N'
    }
  ]);

}