# v0.8.28 port status

| Historical item | v0.8.28 status | Action |
|---|---|---|
| Canon note patch 0004 | Integrated | No patch required; markers verified by `canon_sync`. |
| Research note patch 0005 | Integrated | No patch required; markers verified by `canon_sync`. |
| Chronos--Kelvin code patch 0001 | Semantically relevant | Rebase/test in the current SSTcore repository. |
| `rho_horn` alias patch 0002 | Terminology still relevant | Rebase/test in current SSTcore; `rho_horn` is an envelope normalization, not a resolved-tube density. |
| CODATA/provenance patch 0003 | Historical | Do not blindly apply; v0.8.28 has later provenance and frozen SST anchors. |
| Robustness/GUI patches 0006--0008 | Workbench-local | Rebase/test against the current Workbench tree. |
| v0.8.17 numerical suite | Upgraded | Retained as regression ledger; adds frozen-anchor, action--phase, and canon-sync sections. |
| v0.8.28 mass-shell clock route | New evidence layer | Algebra and finite-difference checks added; substrate derivation remains open. |
