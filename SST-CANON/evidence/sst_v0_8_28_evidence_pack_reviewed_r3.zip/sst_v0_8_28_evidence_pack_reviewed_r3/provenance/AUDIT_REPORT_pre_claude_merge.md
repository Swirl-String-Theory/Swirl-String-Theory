# SST v0.8.17 evidence pack -> SST Canon v0.8.28 port audit

## Executive verdict

The old pack can be carried forward, but not as a blind patch bundle. In v0.8.28:

- the six main/research evidence notes from historical patches 0004/0005 are already integrated;
- the inherited numerical suite remains useful as a regression ledger;
- the canon now contains a new conditional action--phase mass--shell clock route that requires its own evidence section;
- repository-local C++/GUI patches cannot be certified without the matching current repositories.

## New v0.8.28 verification layer

The upgraded suite checks the conditional chain

\[
H(P,I)=\sqrt{P^2c^2+E_0^2(I)},\qquad
V=\frac{Pc^2}{H},\qquad
\frac{E_0}{H}=\gamma^{-1},\qquad
\dot\theta=\left.\frac{\partial H}{\partial I}\right|_P=\frac{\Omega_0}{\gamma}.
\]

It also verifies:

- \(M_0=E_0/c^2\) from the low-momentum expansion;
- the carrier-worldline phase rate \(|d\Phi/dT|=E_0/(\hbar\gamma)\);
- the fixed-momentum derivative numerically;
- preservation of the shape-Hessian signature for the separable mass shell;
- the v0.8.28 residual/guard labels in both LaTeX sources.

## Epistemic boundary

These are algebraic and numerical consequences of the assumed mass shell. They are not a derivation of that shell from an incompressible inviscid substrate. The open tasks remain:

1. identify a concrete hydrodynamic/reduced symplectic action \(I\);
2. derive the joint dispersion relation from the microscopic SST action;
3. verify species-independent limiting speed and clock dressing;
4. compute \((\Delta_{\rm shell},\Delta_V,\Delta_\Omega,\Delta_q)\) on resolved moving-knot solutions.

## Historical patch disposition

See `PORT_STATUS_v0_8_28.md`. Canon-text patches are retired as already integrated. Source-code patches are retained for provenance only and require repository-local rebasing/testing.
