# Adjudication of the Claude v0.8.28 audit pack

## Scope

The supplied standalone audit report and the copy inside the ZIP are byte-identical
(SHA-256 `83a527c943d45af2a8cc36b77242f4b4db6ff540691aa2eebaeacaa6789be6ae`).
The three Python scripts, three proposed canon patches, recorded JSON outputs,
and the frozen v0.8.28 canon sources were inspected.

After installation of the uploaded binary wheel
`sstcore-0.8.18-cp313-cp313-manylinux_2_39_x86_64.whl`, independent reruns in this
environment produced:

- primary upgraded pack: **99/99** graded checks passed;
- Claude numerical ledger: **111/111** graded checks passed;
- all **19/19** live SSTcore-vs-canon checks passed;
- action--phase residual/counter-model harness: **PASS**;
- static canon marker checker: **27/27** required checks passed;
- accepted-patch preview: **226-page LaTeX build succeeded**, with zero unresolved
  references and zero duplicate labels.

This removes the earlier environment caveat. Claude's recorded 111/111 result has now
been independently reproduced with Python 3.13 and SSTcore 0.8.18. The wheel hash,
installation log, and exact runtime environment are stored under
`validation/sstcore_local_install/` and `results/adversarial_rerun_with_sstcore/`.

## Overall verdict

**Accepted with modifications.** The audit is technically useful and largely correct.
It adds stronger adversarial coverage than the first v0.8.28 evidence pack, especially
for the action--phase residual protocol and static canon integrity. No fatal error was
found. Two proposed canon corrections are accepted; one is held pending an explicit
canonical-constant decision.

## Accepted and integrated

### A1. Discriminating action--phase residual harness

The strongest addition is the explicit counter-model test. For the separable bridge

\[
H(P,I,q)=\sqrt{P^2c^2+E_0^2(I,q)},
\]

the residuals remain near the finite-difference floor and `Delta_q` is effectively
zero. A deliberately coupled model generates `Delta_q` up to approximately
`1.94e-1`, monotonically with momentum. This demonstrates that the residual vector
is not vacuous: it can reject a momentum--shape coupling.

Integrated as:

- `scripts/adversarial/rt_action_phase_residuals.py`;
- `results/adversarial_rerun_with_sstcore/rt_action_phase_residuals_full.json` and the corresponding stdout/stderr logs.

### A2. Static LaTeX marker and reference checker

The checker verifies version pins, epistemic guards, action--phase labels, duplicate
labels, and unresolved references across the main canon and research track. It found:

- 320 main-canon labels, zero duplicates;
- 505 research-track labels, zero duplicates;
- zero unresolved references when the companion `\\input` is respected;
- 27/27 required v0.8.28 markers present.

Integrated as `scripts/adversarial/check_canon_markers.py`.

### A3. Compton angular-frequency precision correction

Using the constants embedded in the verification suite,

\[
\omega_c=\frac{m_ec^2}{\hbar}
       =7.76344071105\times10^{20}\ \mathrm{s^{-1}}.
\]

The research track prints `7.76344066e20` in eight locations, and three tabulated
clock rates inherit the stale value. This is a genuine transcription/rounding drift.
The corrected values compile cleanly and do not change the logical status of the
section.

Integrated patch:

- `patches/canon_accepted/0001-precision-omega-c-and-rt-clock-table.patch`.

### A4. Exact-closure benchmark guard

The audit correctly identifies a presentation risk: the five zero-residual mass rows
can be read as predictions even though the note below the table says they are
exact-closure inputs.

Claude's original patch was logically correct but made the table exceed the right
page margin because of overlong column headers. It was therefore not copied verbatim.
A shorter, layout-safe version was produced and visually checked:

- caption: explicitly states that the closure-mass column reproduces experiment by
  construction and is not a prediction;
- column names: `m_closure` and `closure residual`.

Integrated patch:

- `patches/canon_accepted/0002-benchmark-exact-closure-guard-layout-safe.patch`.

### A5. Code-lag and open-theorem ledger

The following audit findings are retained as engineering/research actions, not canon
corrections:

- `SSTcore 0.8.18` lacks an action--phase mass-shell/residual API corresponding to
  canon v0.8.28;
- the resolved SST filament functional and concrete conserved action `I` remain open;
- the preferred-frame/boost-symmetry-breaking bound remains a major falsification
  target;
- KAM-T stage-1 numerics and the full `N=32000` Biot--Savart robustness sweep remain
  unbundled.

## Accepted as findings, but no new canon patch required

### B1. `rho_f` precision ceiling

The audit is correct that every quantity linear in

\[
\rho_{\!f}=7.0\times10^{-7}\ \mathrm{kg\,m^{-3}}
\]

inherits the two-significant-figure calibration ceiling. The current main canon
already contains a strong `[CALIBRATED / PROVENANCE GUARD]` that forbids promotion
of claims requiring better precision and asks for either an independent calibration
observable or an interval-valued parameter. Therefore no duplicate text patch was
added. The issue remains open and is carried in the audit ledger.

### B2. Closed vocabulary for epistemic labels

The audit's editorial suggestion is valid: variants such as `[CALIBRATED IDENTITY]`,
`[CALIBRATED CHAIN GUARD]`, and `[CALIBRATED CONSISTENCY TEST]` are semantically
useful but complicate automated counting. This is retained as a future schema task,
not a numerical or physics correction.

## Held pending explicit decision

### H1. `F_swirl^max` printed value

The audit proposes changing

\[
F_{\mathrm{swirl}}^{\max}=29.053507\ \mathrm{N}
\]

to `29.053510 N`. Re-evaluation of the calibrated formula with the suite's CODATA
inputs gives

\[
\frac{\hbar\omega_c}{2r_c}=29.05351013\ \mathrm{N},
\]

a relative difference of approximately `1.08e-7` from the printed value.

The numerical observation is real. However, `29.053507 N` is also a user-locked SST
canonical constant. Applying the patch would therefore be a canonical rebaselining,
not merely editorial rounding. It has been preserved under

- `patches/canon_held/HELD-precision-fmax-printed-value.patch`

and was **not** applied to the hotfix preview. A future canon version should choose one
of two explicit policies:

1. retain `29.053507 N` as a frozen calibration datum and add a rounding/provenance
   note; or
2. define the force strictly by the current CODATA chain and update the canonical
   printed constant to `29.053510 N` with a versioned changelog entry.

## Findings resolved in the supplied working tree

### R1. Research-track filename mismatch

Claude could not decide whether dots or underscores were used locally. In the actual
v0.8.28 package inspected here, the main file contains

```latex
\input{SST_CANON-v0.8.28-research-track}
```

and the companion filename is `SST_CANON-v0.8.28-research-track.tex`. The coupling is
therefore correct in this package.

### R2. Cross-document reference warnings

The main canon directly inputs the companion. Consequently the 35 main-to-RT and 14
RT-to-main references resolve in the combined build. They are only warnings when the
research-track fragment is treated incorrectly as a standalone document.

## Resulting evidence architecture

The reviewed pack intentionally retains two numerical ledgers rather than merging
their pass counts:

1. `scripts/sst_v0_8_28_verification_suite.py` -- the original upgraded/ported suite
   (**99/99** independently reproduced);
2. `scripts/adversarial/sst_v0_8_28_verification_suite.py` -- Claude's independent
   adversarial ledger (**111/111** independently reproduced with SSTcore 0.8.18).

The earlier 92/92 rerun without SSTcore is retained for provenance. The authoritative
local rerun is now under `results/adversarial_rerun_with_sstcore/`.

This preserves independent provenance and prevents a misleading synthetic
`210/210` headline. Passing either or both suites demonstrates internal consistency
of the checked identities, not empirical confirmation of SST.
