#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_canon_markers.py
======================
Static integrity checker for SST_CANON-v0.8.28(.tex) and its research-track
companion.  This is the LaTeX-side complement of the numerical claim ledger:
the suite checks numbers, this script checks that the canon still *says* what
the numbers were verified against.

Checks performed
----------------
  1. version pin                (\\canonversion{0.8.28} and title agreement)
  2. required v0.8.28 markers   (action-phase mass-shell bridge block)
  3. required standing guards   (calibration-chain, alpha-gate, rho_f
                                 provenance, rho_calc retirement, 16 pi^2
                                 erratum, Rydberg circularity note)
  4. cross-file pointers        (main canon -> RT residual section)
  5. duplicate \\label detection (multiply-defined labels)
  6. dangling \\ref/\\eqref      (referenced labels that are never defined)
  7. epistemic-label census     (per file)
  8. stale-version scan         (inline "v0.8.1x"/"v0.8.2x" strings outside the
                                 changelog, which are usually stale pointers)

Exit code 0 only if all REQUIRED checks pass (1-6).  The census and stale scan
are reported but never fail the run.

Usage:
    python3 check_canon_markers.py                     # defaults to /mnt/project
    python3 check_canon_markers.py MAIN.tex RT.tex
    python3 check_canon_markers.py MAIN.tex RT.tex --json report.json
"""

import os
import re
import sys
import json
import argparse
from collections import Counter

DEFAULT_MAIN = "/mnt/project/SST_CANON-v0_8_28.tex"
DEFAULT_RT = "/mnt/project/SST_CANON-v0_8_28-research-track.tex"

EXPECTED_VERSION = "0.8.28"

# --- required content markers ---------------------------------------------
REQUIRED_MAIN = [
    (r"\\newcommand\{\\canonversion\}\{0\.8\.28\}", "canonversion macro pinned to 0.8.28"),
    (r"eq:action_phase_mass_shell_hamiltonian", "v0.8.28 mass-shell Hamiltonian label"),
    (r"eq:action_phase_internal_clock_dilation", "v0.8.28 internal clock-dilation label"),
    (r"eq:action_phase_shape_extremum_equivalence", "no-shape-deformation consequence"),
    (r"Fixed-momentum guard", "fixed-momentum guard paragraph"),
    (r"TRANSLATION/INTERNAL-RATE DISCIPLINE", "v0.8.28 rate-discipline block"),
    (r"16\\pi\^2\\hbar R_\\infty\^2 c", "corrected 16 pi^2 Rydberg form of F_max"),
    (r"\[ERRATUM\]", "explicit erratum note for the 32 pi^2 -> 16 pi^2 fix"),
    (r"CALIBRATED CHAIN GUARD", "r_c calibration-chain guard"),
    (r"ALPHA-GATE GUARD", "4/alpha gate guard"),
    (r"PROVENANCE GUARD", "rho_f provenance guard"),
    (r"NOTATION RETIREMENT", "rho_calc retirement note"),
    (r"eq:M0_me_quarter_reduction", "M_0 = (m_e/4) L_tot transparency identity"),
    (r"eq:kernel_normalization_scale_guard", "kernel normalization scale guard"),
    (r"consistency check, not an independent non-circular derivation",
     "Rydberg circularity note"),
    (r"sec:rt_action_phase_mass_shell_clock", "pointer to the RT residual section"),
]

REQUIRED_RT = [
    (r"\\label\{sec:rt_action_phase_mass_shell_clock\}", "RT action-phase section anchor"),
    (r"eq:rt_action_phase_residual_vector", "RT residual vector definition"),
    (r"FIXED-MOMENTUM GUARD", "RT fixed-momentum guard"),
    (r"\\Delta_\{\\rm shell\}", "Delta_shell residual"),
    (r"\\Delta_V", "Delta_V residual"),
    (r"\\Delta_\\Omega", "Delta_Omega residual"),
    (r"\\Delta_q", "Delta_q residual"),
]

LABELS = ["[ORTHODOX]", "[DERIVED]", "[CALIBRATED]", "[SPECULATIVE]",
          "[CRITICAL NOTE]", "[RESEARCH-TRACK]", "[PENDING DERIVATION]",
          "[DERIVED NEGATIVE]", "[MATCHING ANSATZ]", "[REFORMULATION]",
          "[CONDITIONAL DERIVED]", "[OPEN THEOREM TARGET]", "[POSIT]",
          "[NEEDS NUMERICS]", "[OBSTRUCTION]"]


def read(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def check_markers(text, required, filename, results):
    for pattern, desc in required:
        found = re.search(pattern, text) is not None
        results.append(dict(file=filename, kind="marker", desc=desc,
                            ok=found, detail=pattern))
        print(f"  [{'PASS' if found else 'FAIL'}] {filename}: {desc}")


def check_labels(text, filename, results):
    labels = re.findall(r"\\label\{([^}]*)\}", text)
    dupes = [l for l, n in Counter(labels).items() if n > 1]
    ok = not dupes
    results.append(dict(file=filename, kind="labels", desc="no duplicate \\label",
                        ok=ok, detail=dupes[:20], n_labels=len(labels)))
    print(f"  [{'PASS' if ok else 'FAIL'}] {filename}: {len(labels)} labels, "
          f"{len(dupes)} duplicated"
          + (f" -> {dupes[:5]}" if dupes else ""))
    return set(labels)


def check_refs(text, defined, companion, filename, results):
    """Dangling references are split into two classes:
      * cross-document  -- resolved in the companion file: these are legitimate
        editorial pointers, but they still emit `undefined reference` on a
        standalone pdflatex pass unless \\externaldocument (package xr) is used.
        Reported as WARN, not FAIL.
      * unresolved      -- defined nowhere: a hard FAIL.
    """
    refs = set(re.findall(r"\\(?:eq)?ref\{([^}]*)\}", text))
    refs |= set(re.findall(r"\\eqref\{([^}]*)\}", text))
    dangling = sorted(r for r in refs if r not in defined)
    cross = sorted(r for r in dangling if r in companion)
    unresolved = sorted(r for r in dangling if r not in companion)
    ok = not unresolved
    results.append(dict(file=filename, kind="refs",
                        desc="no unresolved \\ref/\\eqref", ok=ok,
                        detail=dict(unresolved=unresolved[:30],
                                    cross_document=cross[:40]),
                        n_refs=len(refs), n_cross=len(cross),
                        n_unresolved=len(unresolved)))
    print(f"  [{'PASS' if ok else 'FAIL'}] {filename}: {len(refs)} refs, "
          f"{len(unresolved)} unresolved"
          + (f" -> {unresolved[:5]}" if unresolved else ""))
    if cross:
        print(f"  [WARN] {filename}: {len(cross)} cross-document pointers into the "
              f"companion file; a standalone pdflatex pass will report them as "
              f"undefined unless package xr/\\externaldocument is used.")
        print(f"           e.g. {cross[:4]}")


def census(text, filename, results):
    counts = {lab: text.count(lab) for lab in LABELS}
    counts = {k: v for k, v in counts.items() if v}
    results.append(dict(file=filename, kind="census", desc="epistemic label census",
                        ok=None, detail=counts))
    print(f"  [INFO] {filename} label census:")
    for k, v in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"           {k:<24} {v}")


def stale_versions(text, filename, results):
    hits = Counter(re.findall(r"v0\.8\.(\d+)", text))
    stale = {f"v0.8.{k}": v for k, v in hits.items()
             if k != EXPECTED_VERSION.split(".")[-1]}
    results.append(dict(file=filename, kind="stale", desc="inline version strings",
                        ok=None, detail=stale))
    print(f"  [INFO] {filename} inline version strings (changelog entries expected): "
          f"{dict(sorted(stale.items()))}")


def main():
    ap = argparse.ArgumentParser(description="SST canon v0.8.28 marker checker")
    ap.add_argument("main", nargs="?", default=DEFAULT_MAIN)
    ap.add_argument("rt", nargs="?", default=DEFAULT_RT)
    ap.add_argument("--json", metavar="FILE")
    args = ap.parse_args()

    for p in (args.main, args.rt):
        if not os.path.exists(p):
            print(f"ERROR: missing file {p}")
            return 2

    main_txt = read(args.main)
    rt_txt = read(args.rt)
    mname, rname = os.path.basename(args.main), os.path.basename(args.rt)
    results = []

    print("#"*78)
    print(f"# SST canon marker check -- expected canon version v{EXPECTED_VERSION}")
    print("#"*78)

    print("\n-- required markers: main canon --")
    check_markers(main_txt, REQUIRED_MAIN, mname, results)

    print("\n-- required markers: research track --")
    check_markers(rt_txt, REQUIRED_RT, rname, results)

    print("\n-- structural integrity --")
    lab_main = check_labels(main_txt, mname, results)
    lab_rt = check_labels(rt_txt, rname, results)
    check_refs(main_txt, lab_main, lab_rt, mname, results)
    # the RT companion legitimately points at main-canon labels
    check_refs(rt_txt, lab_rt, lab_main, rname, results)

    print("\n-- informational --")
    census(main_txt, mname, results)
    census(rt_txt, rname, results)
    stale_versions(main_txt, mname, results)
    stale_versions(rt_txt, rname, results)

    graded = [r for r in results if r["ok"] is not None]
    npass = sum(1 for r in graded if r["ok"])
    print()
    print("="*78)
    print(f"RESULT: {npass}/{len(graded)} required checks passed")
    print("="*78)

    if args.json:
        with open(args.json, "w") as f:
            json.dump({"canon_version": EXPECTED_VERSION,
                       "passed": npass, "total": len(graded),
                       "results": results}, f, indent=2)
        print(f"[wrote {args.json}]")

    return 0 if npass == len(graded) else 1


if __name__ == "__main__":
    raise SystemExit(main())
