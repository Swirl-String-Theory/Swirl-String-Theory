# SST Canon v0.8.28 evidence pack -- reviewed revision 3

This package combines the v0.8.17-to-v0.8.28 port with Claude's independent
adversarial audit and a complete local rerun against the uploaded binary wheel
`SSTcore 0.8.18`.

The external audit was not accepted wholesale: its scripts and claims were rerun,
its patches were adjudicated, and the benchmark-table patch was rewritten to avoid
a LaTeX layout regression.

Start with:

1. `AUDIT_REPORT_v0_8_28.md` -- consolidated verdict;
2. `ADJUDICATION_CLAUDE_AUDIT.md` -- detailed review;
3. `PATCH_DISPOSITION.md` -- accepted, rewritten, and held patches.

## Reproduced verification status

- primary upgraded suite: **99/99**;
- Claude adversarial suite with the uploaded `SSTcore 0.8.18` wheel: **111/111**;
- action--phase residual/counter-model harness: **PASS**;
- canon marker/reference checker: **27/27**;
- accepted-patch LaTeX preview: **226 pages**, build succeeded;
- SSTcore import: **PASS**, version `0.8.18`, 233 native functions exposed.

The 111/111 result is now an independent rerun in this environment, not merely a
stored external result. Its 19 live code-vs-canon checks all pass. The rerun also
confirms the two code gaps identified by Claude: SSTcore has no v0.8.28 action--phase
API and no helper for the `M_0=(m_e/4)L_tot` transparency identity.

Pass counts are deliberately not added together because the suites overlap. They
establish internal algebraic, numerical, source, and code-mirror consistency only;
they are not empirical evidence for SST.

## Verification commands

Primary upgraded ledger:

```bash
python3 scripts/sst_v0_8_28_verification_suite.py \
  --json results/suite_results_v0_8_28.json
```

Independent adversarial ledger:

```bash
python3 scripts/adversarial/sst_v0_8_28_verification_suite.py \
  --json results/adversarial_rerun_with_sstcore/suite_results_v0_8_28_full.json
```

Action--phase residual protocol and coupled counter-model:

```bash
python3 scripts/adversarial/rt_action_phase_residuals.py \
  --json results/adversarial_rerun_with_sstcore/rt_action_phase_residuals_full.json
```

Canon structure:

```bash
python3 scripts/adversarial/check_canon_markers.py \
  canon_snapshot/SST_CANON-v0.8.28.tex \
  canon_snapshot/SST_CANON-v0.8.28-research-track.tex \
  --json results/adversarial_rerun_with_sstcore/canon_marker_report_full.json
```

## Directory layout

- `canon_snapshot/` -- untouched v0.8.28 sources;
- `canon_hotfix_preview/` -- compile-verified preview with accepted minor patches;
- `patches/canon_accepted/` -- accepted dot-filename patches;
- `patches/canon_held/` -- patch requiring an explicit canon decision;
- `scripts/` -- primary verification suite and inherited reproducers;
- `scripts/adversarial/` -- Claude ledger, residual harness, and marker checker;
- `results/adversarial_rerun_with_sstcore/` -- full 111/111 independent rerun;
- `results/adversarial_rerun/` -- earlier 92/92 rerun without the binary package;
- `results/claude_recorded/` -- original Claude outputs;
- `validation/sstcore_local_install/` -- wheel hash, environment, and install log;
- `external_reviews/claude/original/` -- source audit and original patches;
- `validation/` -- compile logs, marker report, syntax checks, and page renders;
- `legacy_repo_patches/` -- historical repository patches retained for provenance;
- `provenance/` -- predecessor audit/results and pre-merge audit.

## Scope guard

The mass-shell identity

\[
H(P,I)=\sqrt{P^2c^2+E_0^2(I)}
\]

conditionally implies

\[
\dot\theta=\left.\frac{\partial H}{\partial I}\right|_P
=\frac{\Omega_0}{\gamma}.
\]

The evidence pack does not derive that mass shell, the action variable `I`, or a
species-independent limiting speed from the SST substrate. Passing checks establish
only the stated algebraic, numerical, structural, or code-mirror consistency.
