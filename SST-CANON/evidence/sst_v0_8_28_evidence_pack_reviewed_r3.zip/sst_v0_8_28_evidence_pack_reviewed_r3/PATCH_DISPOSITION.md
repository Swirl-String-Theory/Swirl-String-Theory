# Canon patch disposition after Claude-audit review

| Patch | Disposition | Reason |
|---|---|---|
| `0001-precision-omega-c-and-rt-clock-table.patch` | **ACCEPTED** | Corrects a reproducible stale numerical value and dependent table entries. |
| `0002-benchmark-exact-closure-guard-layout-safe.patch` | **ACCEPTED, REWRITTEN** | Audit intent is correct; original wording overflowed the table. The replacement preserves the warning and page layout. |
| `HELD-precision-fmax-printed-value.patch` | **HELD** | Formula re-evaluation favors `29.053510 N`, but `29.053507 N` is currently a locked SST canonical datum. Requires explicit versioned rebaselining decision. |
| `rho_f` precision warning | **NO PATCH** | The main canon already contains the required provenance and precision ceiling guard. |
| SSTcore action--phase API | **CODE ACTION REQUIRED** | Needs the current SSTcore source repository; no speculative repository patch is emitted from an evidence-only bundle. |

## Applying accepted patches

From a directory containing the dot-versioned v0.8.28 files:

```bash
patch -p1 --dry-run -i patches/canon_accepted/0001-precision-omega-c-and-rt-clock-table.patch
patch -p1 --dry-run -i patches/canon_accepted/0002-benchmark-exact-closure-guard-layout-safe.patch

patch -p1 -i patches/canon_accepted/0001-precision-omega-c-and-rt-clock-table.patch
patch -p1 -i patches/canon_accepted/0002-benchmark-exact-closure-guard-layout-safe.patch
```

The combined preview in `canon_hotfix_preview/` compiles successfully to 226 pages.
