# Minimum SSTcore action--phase API target

This is a code-surface specification, not a claim that the mass shell has been
substrate-derived.

## Required pure functions

```cpp
double mass_shell_hamiltonian(double P, double E0, double c);
double translation_velocity(double P, double H, double c);
double internal_phase_rate(double H, double E0, double Omega0);
ActionPhaseResiduals residual_vector(
    double P,
    double H,
    double E0,
    double V,
    double Omega,
    double Omega0,
    double delta_q
);
```

with

\[
H=\sqrt{P^2c^2+E_0^2},\qquad
V=\frac{Pc^2}{H},\qquad
\Omega=\frac{E_0}{H}\Omega_0.
\]

## Required residuals

\[
\Delta_{\rm shell}=\frac{H^2-P^2c^2-E_0^2}{E_0^2},
\]

\[
\Delta_V=\frac{VH}{Pc^2}-1,
\qquad
\Delta_\Omega=\frac{\Omega H}{\Omega_0E_0}-1,
\]

plus the resolved-solution shape residual `Delta_q` defined by the canon.

## Required guards

- derivatives with respect to the internal action must be taken at fixed `P`, not
  fixed `V`;
- the API must not name the result a substrate derivation;
- no flattening, stretching, or core-thinning law may be inferred from the separable
  mass shell alone;
- tests must include the deliberately coupled counter-model from
  `scripts/adversarial/rt_action_phase_residuals.py`.
