# SST Canon v0.8.28 evidence pack -- consolidated audit, revision 3

## Executive verdict

**[READY WITH MINOR PATCHES].**

The original v0.8.17-to-v0.8.28 port and Claude's independent adversarial audit
were checked together. No fatal error was found. The uploaded SSTcore wheel allowed
the previously unavailable live code-mirror section to be rerun completely.

The action--phase bridge remains correctly classified as an orthodox mass-shell form
used conditionally inside SST, not as a derivation from the substrate.

## Fully reproduced verification status

| Layer | Independent result | Scope |
|---|---:|---|
| Primary upgraded suite | **99/99** | inherited regressions, v0.8.28 anchors, action--phase algebra, source synchronization |
| Claude adversarial suite + SSTcore 0.8.18 | **111/111** | complete 13-section numerical claim ledger, including 19 live code-vs-canon checks |
| Action--phase counter-model harness | **PASS** | `Delta_q` detects explicit momentum--shape coupling |
| Canon marker/reference checker | **27/27** | zero duplicate labels and zero unresolved references across main+RT |
| Accepted-patch preview | **PASS** | LaTeX build succeeded, 226 pages |

The local binary import reports SSTcore version `0.8.18` and 233 exposed native
functions. The package was installed from the uploaded CPython-3.13 manylinux wheel;
its SHA-256 is recorded under `validation/sstcore_local_install/`.

Pass counts are not summed because the two suites overlap. They establish internal
consistency only, not empirical support for SST.

## What the completed SSTcore rerun establishes

All 19 live code-vs-canon comparisons pass, including:

- `omega_c`, `r_c`, `Gamma_0`, `rho_E`, `rho_m`, and `rho_horn`;
- the non-reduced Compton gate `lambda_c/(pi r_c)=4/alpha`;
- both code paths for `F_swirl^max`;
- the Rydberg identity;
- the force hierarchy and Coulomb-force closure;
- spring frequency and energy identities;
- `G_swirl=G` under the explicit Planck-time import;
- the Swirl Clock and Chronos--Kelvin vorticity convention.

The completed rerun also independently confirms Claude's code-lag finding:

1. SSTcore exposes no entry point for the v0.8.28 action--phase mass-shell bridge or
   its residual vector;
2. SSTcore exposes no helper for
   \(M_0(T)=(m_e/4)L_{\rm tot}(T)\).

These are API gaps, not failures of the checked canon equations.

## Accepted canon corrections

1. Correct stale research-track values based on
   \(\omega_c=m_ec^2/\hbar=7.76344071105\times10^{20}\,\mathrm{s^{-1}}\).
2. Make the exact-closure nature of the benchmark mass table visible in its caption
   and headings. The integrated version is shorter than Claude's original patch to
   avoid a right-margin overflow.

See `PATCH_DISPOSITION.md` and `patches/canon_accepted/`.

## Held correction

The proposal to change

\[
F_{\mathrm{swirl}}^{\max}=29.053507\ \mathrm{N}
\]

to `29.053510 N` is numerically supported by the current calibrated code path, which
returns approximately `29.05351013 N`. It nevertheless changes a user-locked canon
constant and is therefore retained as a held, versioned rebaselining decision rather
than silently applied.

## Major open items retained

- independent provenance or interval calibration for \(\rho_{\!f}\);
- derivation of the joint mass shell and a concrete conserved action \(I\) from the
  SST substrate;
- replacement of the surrogate \(E_0(I,q)\) by a resolved SST filament functional;
- resolved moving-knot calculation of
  \((\Delta_{\rm shell},\Delta_V,\Delta_\Omega,\Delta_q)\);
- SSTcore implementation of the v0.8.28 action--phase API;
- preferred-frame/boost-symmetry-breaking bound;
- KAM-T stage-1 numerics and full `N=32000` Biot--Savart sweep;
- predictive mass rows separated from exact-closure bookkeeping.

## Detailed review

Read `ADJUDICATION_CLAUDE_AUDIT.md` for the claim-by-claim disposition, numerical
precision decisions, layout correction, and code-action recommendations.
