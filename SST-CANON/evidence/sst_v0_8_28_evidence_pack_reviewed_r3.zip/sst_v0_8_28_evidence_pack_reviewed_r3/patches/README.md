# Patch status for the reviewed v0.8.28 evidence pack

- `0001-upgrade-verification-suite-v0.8.17-to-v0.8.28.patch` remains the portable
  diff of the original verification suite.
- `canon_accepted/0001-precision-omega-c-and-rt-clock-table.patch` corrects the
  stale Compton angular-frequency values in the research track.
- `canon_accepted/0002-benchmark-exact-closure-guard-layout-safe.patch` makes the
  benchmark table's tautological exact-closure status explicit without overflowing
  the page.
- `canon_held/HELD-precision-fmax-printed-value.patch` is not approved for automatic
  application because it would alter a user-locked canonical constant.
- Historical canon-text patches `0004` and `0005` remain retired because their
  evidence guards are already present in v0.8.28.
- Historical repository patches remain under `legacy_repo_patches/`; they have not
  been rebased against absent current SSTcore/Workbench repositories.

See the top-level `PATCH_DISPOSITION.md` for the full adjudication.
