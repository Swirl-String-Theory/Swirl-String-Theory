# v0.8.28 port status

*Adopted from the parallel ChatGPT evidence pack and extended. Rows marked
**[rev2]** are additions or corrections made during the cross-audit; see
`CROSS_AUDIT_chatgpt_pack.md`.*

| Historical item | v0.8.28 status | Action |
|---|---|---|
| Canon note patch 0004 | Integrated | No patch required; markers verified by `canon_sync`. |
| Research note patch 0005 | Integrated | No patch required; markers verified by `canon_sync`. |
| Chronos--Kelvin code patch 0001 | Semantically relevant | Rebase/test in the current SSTcore repository. |
| `rho_horn` alias patch 0002 | Terminology still relevant | Rebase/test in current SSTcore; `rho_horn` is an envelope normalization, not a resolved-tube density. |
| CODATA/provenance patch 0003 | Historical | Do not blindly apply; v0.8.28 has later provenance and frozen SST anchors. |
| Robustness/GUI patches 0006--0008 | Workbench-local | Rebase/test against the current Workbench tree. |
| v0.8.17 numerical suite | Upgraded | Retained as regression ledger; adds frozen-anchor, action--phase, and canon-sync sections. |
| v0.8.28 mass-shell clock route | New evidence layer | Algebra and finite-difference checks added; substrate derivation remains open. |

## [rev2] additions

| Item | v0.8.28 status | Action |
|---|---|---|
| CODATA release pin | Ambiguous in canon | Bibliography cites CODATA-2022 (`Mohr2025CODATA`), anchors are CODATA-2018-derived. Pin one release in canon and SSTcore. Do **not** mix (as the parallel pack did for `alpha` only). |
| SSTcore alignment method | Upgraded | Hand-mirrored C++ formulas replaced by live calls into the installed `SSTcore 0.8.18`. |
| SSTcore action-phase API | Missing | `[API GAP]`: no entry point for the v0.8.28 mass-shell bridge or the residual vector. Code patch required. |
| Canon text defects | Newly found | Patches `0001`-`0004`: `F_max` 7th digit, `omega_c` 8th digit (8 sites) + 3 derived table values, benchmark-table tautology guard, `r_c` 9th digit (10 sites). |
| Legacy `rho_core` (17 digits) | Stale, corpus-wide | Present in 8+ papers; inconsistent with the v0.8.28 closure at `1.2e-7`. One deliberate corpus pass required. |
| Canon snapshot | Adopted with a fix | Snapshot alone cannot detect drift; `scripts/manifest_and_drift.py` compares it against the live canon. |
| Residual protocol | Validated | Counter-model added: an explicit `H_Pq` coupling drives `Delta_q` to `1.9e-1`, proving the protocol discriminates. |
| `\paperdoi` | Upstream ahead | Local canon carries `10.5281/zenodo.21628167`; Project Knowledge copy is empty. `[PROVISIONAL CANON UPDATE]`, no patch. |
