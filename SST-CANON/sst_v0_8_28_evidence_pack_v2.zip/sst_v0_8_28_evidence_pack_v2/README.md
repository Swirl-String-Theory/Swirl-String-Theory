# SST Canon v0.8.28 — evidence pack (rev 2, merged)

Successor to `sst_v0_8_17_evidence_pack_port`. Built directly against the
v0.8.28 canon files, not ported by relabelling. Revision 2 merges the reviewed
material from a parallel ChatGPT evidence pack.

**Read in this order:**
1. `AUDIT_REPORT_v0_8_28.md` — the canon audit
2. `CROSS_AUDIT_chatgpt_pack.md` — what was adopted from the parallel pack and what was rejected
3. `PORT_STATUS_v0_8_28.md` — disposition of historical patches

---

## Contents

```
AUDIT_REPORT_v0_8_28.md        referee-style canon audit (verdict, issues, recommendations)
CROSS_AUDIT_chatgpt_pack.md    review of the parallel ChatGPT pack: adopted / rejected
PORT_STATUS_v0_8_28.md         disposition of historical patches
MANIFEST.json                  sha256 + size of every file in this pack
README.md                      this file

scripts/
  sst_v0_8_28_verification_suite.py   16-section numerical claim ledger (128 graded checks)
  rt_action_phase_residuals.py        v0.8.28 residual protocol + discriminating counter-model
  check_canon_markers.py              static LaTeX marker / structural checker
  manifest_and_drift.py               manifest generator + canon snapshot drift detector

canon_snapshot/                the exact canon the results were produced against
  SST_CANON-v0_8_28.tex
  SST_CANON-v0_8_28-research-track.tex

patches/                       canon patches (dry-run + sequentially verified)
  0001-precision-fmax-printed-value.patch          F_max: 29.053507 -> 29.053510 N (2 sites)
  0002-precision-omega-c-and-rt-clock-table.patch  omega_c: ...066 -> ...071 (8 sites) + 3 table values
  0003-benchmark-table-tautology-guard.patch       benchmark table: mark closure inputs as inputs
  0004-precision-rc-ninth-digit.patch              r_c: 1.40897017e-15 -> 1.40897016e-15 (10 sites)

legacy_repo_patches/           SSTcore / Workbench patches carried from the v0.8.17 pack
provenance/                    v0.8.17 pack lineage + the ChatGPT pack's own audit, manifest and suite

results/
  suite_results_v0_8_28.json          machine-readable ledger
  suite_stdout.txt / suite_stderr.txt
  rt_action_phase_residuals.json      Model A / Model B / fixed-V guard tables
  rt_action_phase_residuals_stdout.txt
  canon_marker_report.json            marker + label census + ref analysis
  canon_marker_stdout.txt
  snapshot_drift.json                 snapshot vs live canon comparison
  environment.json                    versions this pack was run under
```

## How to run

```bash
pip install numpy SSTcore --break-system-packages     # SSTcore optional but recommended

python3 scripts/sst_v0_8_28_verification_suite.py --json results/suite_results_v0_8_28.json
python3 scripts/rt_action_phase_residuals.py         --json results/rt_action_phase_residuals.json
python3 scripts/check_canon_markers.py  MAIN.tex RT.tex --json results/canon_marker_report.json
python3 scripts/manifest_and_drift.py   --live /path/to/live/canon
```

`manifest_and_drift.py` regenerates `MANIFEST.json` and compares
`canon_snapshot/` against a live canon directory, classifying each file as
`IDENTICAL`, `EOL ONLY`, or `CONTENT DRIFT`. Run it before citing any number
from `results/`: a snapshot that is never compared is provenance theatre.

`check_canon_markers.py` defaults to `/mnt/project/SST_CANON-v0_8_28*.tex`; pass
your local paths as the first two arguments.

Suite sections can be run individually:

```bash
python3 scripts/sst_v0_8_28_verification_suite.py --list
python3 scripts/sst_v0_8_28_verification_suite.py --only constants actionphase massbaseline
```

Exit code is 0 only when every graded check passes.

## Applying the patches

```bash
cd /path/to/canon
patch -p1 --dry-run -i .../patches/0001-precision-fmax-printed-value.patch
patch -p1 --dry-run -i .../patches/0002-precision-omega-c-and-rt-clock-table.patch
patch -p1 --dry-run -i .../patches/0003-benchmark-table-tautology-guard.patch
```

Merge order `0001 → 0002 → 0003`, verified sequentially in this container.
Line endings are preserved as found: CRLF for `SST_CANON-v0_8_28.tex`, LF for
`SST_CANON-v0_8_28-research-track.tex`. Patch `0001`/`0003` touch the main canon,
`0002` touches the research track only. After applying, `check_canon_markers.py`
still returns 27/27.

## Run recorded in `results/`

| | |
|---|---|
| Canon | v0.8.28 (main 7313 lines, RT 11152 lines) |
| Suite | **128/128 graded checks passed**, 16 sections |
| Residual harness | Model A max residual `4.35e-07`; Model B max `Delta_q` `1.94e-01`, monotone; guard `PASS` |
| Marker check | **27/27 required**, 0 duplicate labels, 0 unresolved refs, 49 cross-document pointers (resolved via `\input`) |
| Snapshot drift | `IDENTICAL` to the live Project Knowledge canon |
| Documented defects | `r_c` 9th digit, legacy 17-digit `rho_core` (both tracked as regression guards) |
| Python / numpy / SSTcore | 3.12 / 2.4.4 / **0.8.18** |

## Scope and limits

This pack is a **numerical claim ledger plus a static marker checker**. It is
not a LaTeX compilation test, not a proof of canon consistency, and not
evidence for SST. Most passing checks are `[CALIBRATED]` identities that are
forced once `vchar = alpha c/2` is adopted; the ledger labels each one at the
point of use. The `alpha` section deliberately records **no** pass/fail,
because an obstruction is not a check that can be passed.

Two suite checks are **documented-defect regression guards**: they pass while a
known defect is still present as described, and fail if the number silently
drifts or is fixed without updating the ledger. They are not evidence that the
canon is correct at those points — the opposite.

Open items carried forward unchanged: `rho_f` provenance, `alpha` ppm closure
(blocked at gates `G_0`/`G_1`), `theta = pi` superselection, KAM-T stage-1
numerics, and the boost-symmetry-breaking bound.
