#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
manifest_and_drift.py
=====================
Two jobs, both about provenance:

  1. **MANIFEST.json** — sha256 + byte size of every file in the pack, so a
     result can always be tied to the exact artefact that produced it.
     (Idea adopted from the parallel ChatGPT pack, which shipped a manifest.)

  2. **Snapshot drift** — the pack carries a frozen `canon_snapshot/` copy of
     the canon it was verified against. This compares that snapshot against a
     live canon directory and classifies every difference:

        [IDENTICAL]        byte-for-byte equal
        [EOL ONLY]         identical after CRLF/LF normalization
        [CONTENT DRIFT]    real textual difference -> the pack's results may
                           no longer describe the live canon

     A frozen snapshot that can never be compared is provenance theatre; the
     drift check is what makes it useful.

Usage:
    python3 manifest_and_drift.py                      # manifest + drift vs /mnt/project
    python3 manifest_and_drift.py --live /path/to/canon
    python3 manifest_and_drift.py --no-drift
"""

import os
import sys
import json
import hashlib
import difflib
import argparse

PACK_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SNAPSHOT_DIR = os.path.join(PACK_ROOT, "canon_snapshot")
DEFAULT_LIVE = "/mnt/project"

# snapshot filename -> candidate live filenames (Project Knowledge sanitizes
# dots in filenames to underscores, so both spellings are accepted)
LIVE_CANDIDATES = {
    "SST_CANON-v0_8_28.tex": ["SST_CANON-v0_8_28.tex", "SST_CANON-v0.8.28.tex"],
    "SST_CANON-v0_8_28-research-track.tex": [
        "SST_CANON-v0_8_28-research-track.tex",
        "SST_CANON-v0.8.28-research-track.tex"],
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(root, out_path):
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for fn in sorted(filenames):
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root)
            if rel in ("MANIFEST.json",):
                continue
            files.append(dict(path=rel.replace(os.sep, "/"),
                              bytes=os.path.getsize(full),
                              sha256=sha256(full)))
    files.sort(key=lambda d: d["path"])
    manifest = dict(pack="sst_v0_8_28_evidence_pack_v2",
                    canon_version="0.8.28",
                    file_count=len(files),
                    files=files)
    with open(out_path, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"[manifest] {len(files)} files -> {os.path.relpath(out_path, root)}")
    return manifest


def classify(snap_bytes, live_bytes):
    if snap_bytes == live_bytes:
        return "IDENTICAL", []
    sn = snap_bytes.replace(b"\r\n", b"\n")
    ln = live_bytes.replace(b"\r\n", b"\n")
    if sn == ln:
        return "EOL ONLY", []
    a = sn.decode("utf-8", "replace").split("\n")
    b = ln.decode("utf-8", "replace").split("\n")
    diff = [d for d in difflib.unified_diff(a, b, "snapshot", "live", n=0,
                                            lineterm="")]
    return "CONTENT DRIFT", diff


def drift_check(live_dir):
    print()
    print("="*78)
    print(f"CANON SNAPSHOT DRIFT CHECK  (live: {live_dir})")
    print("="*78)
    worst = 0
    report = []
    for snap_name, candidates in LIVE_CANDIDATES.items():
        snap_path = os.path.join(SNAPSHOT_DIR, snap_name)
        if not os.path.isfile(snap_path):
            print(f"  [FAIL] snapshot missing: {snap_name}")
            worst = max(worst, 2)
            continue
        live_path = None
        for cand in candidates:
            p = os.path.join(live_dir, cand)
            if os.path.isfile(p):
                live_path = p
                break
        if live_path is None:
            print(f"  [SKIP] no live counterpart for {snap_name} in {live_dir}")
            report.append(dict(file=snap_name, status="NO LIVE COPY"))
            continue
        status, diff = classify(open(snap_path, "rb").read(),
                                open(live_path, "rb").read())
        tag = {"IDENTICAL": "PASS", "EOL ONLY": "WARN",
               "CONTENT DRIFT": "FAIL"}[status]
        worst = max(worst, {"PASS": 0, "WARN": 1, "FAIL": 2}[tag])
        print(f"  [{tag}] {snap_name}: {status}"
              f" (live: {os.path.basename(live_path)})")
        entry = dict(file=snap_name, live=os.path.basename(live_path),
                     status=status,
                     snapshot_sha256=sha256(snap_path),
                     live_sha256=sha256(live_path))
        if status == "CONTENT DRIFT":
            shown = [d for d in diff if d.startswith(("+", "-"))
                     and not d.startswith(("+++", "---"))]
            entry["diff_lines"] = shown[:40]
            for line in shown[:12]:
                print(f"         {line[:150]}")
            if len(shown) > 12:
                print(f"         ... {len(shown)-12} more changed lines")
        report.append(entry)
    print()
    if worst == 0:
        print("  Snapshot matches the live canon byte-for-byte.")
    elif worst == 1:
        print("  Snapshot differs only in line endings. Results remain valid, but")
        print("  patches must be generated against the live line-ending style.")
    else:
        print("  CONTENT DRIFT: the results in results/ describe the SNAPSHOT, not")
        print("  the live canon. Re-run the suite before citing any number.")
    return report, worst


def main():
    ap = argparse.ArgumentParser(description="manifest + canon snapshot drift check")
    ap.add_argument("--live", default=DEFAULT_LIVE,
                    help="directory holding the live canon .tex files")
    ap.add_argument("--no-drift", action="store_true")
    ap.add_argument("--json", default=os.path.join(PACK_ROOT, "results",
                                                   "snapshot_drift.json"))
    args = ap.parse_args()

    build_manifest(PACK_ROOT, os.path.join(PACK_ROOT, "MANIFEST.json"))

    if args.no_drift:
        return 0
    report, worst = drift_check(args.live)
    os.makedirs(os.path.dirname(args.json), exist_ok=True)
    with open(args.json, "w") as f:
        json.dump(dict(live_dir=args.live, worst_status=worst, files=report),
                  f, indent=2)
    print(f"[wrote {args.json}]")
    return 0 if worst < 2 else 1


if __name__ == "__main__":
    raise SystemExit(main())
