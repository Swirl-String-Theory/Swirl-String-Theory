import os, math, json, itertools
import numpy as np, trimesh
from scipy.ndimage import gaussian_filter1d

def rotz(a):
    return np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])

def kabsch_similarity(A,B):
    Ac=A-A.mean(0); Bc=B-B.mean(0)
    H=Ac.T@Bc
    U,S,Vt=np.linalg.svd(H)
    R=Vt.T@U.T
    if np.linalg.det(R)<0:
        Vt[-1]*=-1
        R=Vt.T@U.T
    s=np.sum(S)/np.sum(Ac**2)
    t=B.mean(0)-s*(R@A.mean(0))
    return s,R,t

def recover_triple_gear_parameters(stl_path):
    mesh=trimesh.load(stl_path, force='mesh')
    comps=mesh.split()
    if len(comps) != 3:
        raise ValueError(f"Expected 3 connected watertight components, got {len(comps)}")

    # Published normalized geometry
    r = 0.4950197
    theta = -0.8560281
    rho_norm = 0.3228837
    R_norm = 1.0
    U0 = np.array([1.0,0.0,0.0])
    V0 = np.array([0.0, math.sin(theta), math.cos(theta)])
    N0 = np.cross(U0,V0); N0 = N0/np.linalg.norm(N0)

    canon_centers = np.array([
        [r,0,0],
        [r*math.cos(2*math.pi/3), r*math.sin(2*math.pi/3), 0],
        [r*math.cos(4*math.pi/3), r*math.sin(4*math.pi/3), 0],
    ])
    canon_normals=np.array([rotz(k*2*math.pi/3)@N0 for k in range(3)])

    meas_cent=np.array([c.centroid for c in comps])
    pca_normals=[]
    for c in comps:
        X=c.vertices-c.vertices.mean(0)
        w,v=np.linalg.eigh(np.cov(X.T))
        n=v[:,np.argmin(w)]
        pca_normals.append(n/np.linalg.norm(n))
    pca_normals=np.array(pca_normals)

    best=None
    for perm in itertools.permutations(range(3)):
        B=meas_cent[list(perm)]
        s,R,t=kabsch_similarity(canon_centers,B)
        pred=(s*(R@canon_centers.T)).T+t
        err=np.sqrt(((pred-B)**2).sum(1)).mean()
        normals_pred=(R@canon_normals.T).T
        pca=pca_normals[list(perm)]
        ndiff=np.mean([min(np.linalg.norm(normals_pred[i]-pca[i]), np.linalg.norm(normals_pred[i]+pca[i])) for i in range(3)])
        score=err+ndiff
        if best is None or score<best[0]:
            best=(score, perm, s,R,t,err,ndiff)

    score, perm, scale, Rot, trans, center_err, normal_err = best

    report = {
        "component_count": len(comps),
        "canonical_to_mesh_component_permutation": list(map(int, perm)),
        "scale_mm_per_normalized_unit": float(scale),
        "rotation_matrix": Rot.tolist(),
        "translation_mm": trans.tolist(),
        "mean_center_fit_error_mm": float(center_err),
        "mean_normal_fit_error": float(normal_err),
        "paper_normalized_parameters": {
            "r": r,
            "R": R_norm,
            "rho": rho_norm,
            "theta": theta,
        },
        "derived_mesh_parameters_mm": {
            "R_major": float(scale * R_norm),
            "rho_smooth_reference": float(scale * rho_norm),
            "center_radius_r": float(scale * r),
        }
    }
    return report

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("stl_path")
    ap.add_argument("--out", default="triple_gear_parametric_recovery.json")
    args = ap.parse_args()
    rep = recover_triple_gear_parameters(args.stl_path)
    with open(args.out,"w") as f:
        json.dump(rep,f,indent=2)
    print(json.dumps(rep, indent=2))
