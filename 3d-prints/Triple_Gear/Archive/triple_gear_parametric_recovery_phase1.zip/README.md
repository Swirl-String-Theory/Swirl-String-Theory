# Triple gear parametric recovery — phase 1

This package starts the mathematical reconstruction of the uploaded triple-gear mesh from the published Hopf-link torus model.

## What was recovered

A similarity transform was fitted from the normalized paper geometry to the uploaded STL mesh:

- Scale: **20.474860 mm per normalized unit**
- Mean component-center fit error: **1.463493e-08 mm**
- Canonical ring → mesh component permutation: **(1, 0, 2)**
- Global translation: **(0.000000, 0.000000, -0.033493) mm**

This is a very strong result: the uploaded mesh is consistent with the paper's 3-fold symmetric Hopf-link torus placement, not merely visually similar.

## Derived physical mesh dimensions

Using the published normalized parameters \(R=1\), \(r=0.4950197\), \(\rho=0.3228837\):

- Major radius \(R_\text{mesh} \approx 20.4749\,\mathrm{mm}\)
- Smooth reference tube radius \(\rho_\text{mesh} \approx 6.6110\,\mathrm{mm}\)
- Ring-center radius \(r_\text{mesh} \approx 10.1355\,\mathrm{mm}\)

## What the figures show

- `fit_centers.png` — component point clouds with fitted canonical ring centers.
- `unwrap_alpha_beta.png` — vertices of one ring unwrapped to toroidal coordinates \((\alpha,\beta)\); color is signed offset from the smooth reference torus.
- `beta_lane_signal.png` — a first tooth-lane signal versus meridian angle \(\beta\).

## Interpretation

This phase does **not** yet reconstruct exact tooth flanks.
It establishes the canonical toroidal coordinate system needed for that next step.

The remaining reconstruction problem is now:

1. Fit the **inner teeth** as piecewise planar families in toroidal coordinates.
2. Reconstruct the **outer teeth** as an envelope / carving surface under the relative motion of one ring in the frame of another.
3. Use 3-fold symmetry to suppress the maker's mark and other non-kinematic local artifacts.

## Estimated next mathematical step

A clean next fit is

\[
\Theta^\star
=
\arg\min_\Theta
\bigl[
d_H(M(\Theta),M_{\rm STL})
+ \lambda_1 E_{\rm sym}
+ \lambda_2 E_{\rm mesh}
+ \lambda_3 E_{\rm clear}
\bigr].
\]

where \(\Theta\) contains tooth-lane phases, toroidal-plane slopes for the inner teeth, carving-envelope parameters for the outer teeth, and print-clearance offsets.
